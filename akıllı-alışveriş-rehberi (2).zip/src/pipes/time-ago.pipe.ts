import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'timeAgo',
  standalone: true
})
export class TimeAgoPipe implements PipeTransform {

  transform(value: string | Date): string {
    if (!value) return '';

    const date = typeof value === 'string' ? new Date(value) : value;
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (seconds < 29) return 'az önce';
    
    const intervals: { [key: string]: number } = {
      'yıl': 31536000,
      'ay': 2592000,
      'hafta': 604800,
      'gün': 86400,
      'saat': 3600,
      'dakika': 60,
      'saniye': 1
    };
    
    let counter;
    for (const i in intervals) {
      counter = Math.floor(seconds / intervals[i]);
      if (counter > 0) {
        return `${counter} ${i} önce`;
      }
    }
    return value.toString();
  }
}
