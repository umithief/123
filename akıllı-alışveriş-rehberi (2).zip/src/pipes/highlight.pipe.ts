import { Pipe, PipeTransform, inject } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({
  name: 'highlight',
  standalone: true,
})
export class HighlightPipe implements PipeTransform {
  private sanitizer = inject(DomSanitizer);

  transform(text: string | null | undefined, searchTerm: string | null | undefined): SafeHtml | string {
    if (!searchTerm?.trim() || !text) {
      return text || '';
    }

    // Escape special characters in search term for regex
    const safeSearchTerm = searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(safeSearchTerm, 'gi');
    
    if (!text.match(regex)) {
        return text;
    }

    const highlightedText = text.replace(
      regex,
      (match) => `<strong class="bg-indigo-300 dark:bg-indigo-500 text-black rounded-sm px-1">${match}</strong>`
    );

    return this.sanitizer.bypassSecurityTrustHtml(highlightedText);
  }
}
