import { Pipe, PipeTransform, inject } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { GlossaryService } from '../services/glossary.service';

@Pipe({
  name: 'glossary',
  standalone: true,
})
export class GlossaryPipe implements PipeTransform {
  private glossaryService = inject(GlossaryService);
  private sanitizer = inject(DomSanitizer);

  transform(value: string | null | undefined): SafeHtml {
    if (!value) {
      return '';
    }

    let processedHtml = value;
    const terms = this.glossaryService.getTerms();

    terms.forEach(term => {
      // Create a case-insensitive, whole-word-only regex that avoids matching inside HTML tags.
      // This is a simplified approach. For a truly robust solution, a full DOM parser would be needed,
      // but this regex is effective for typical blog content.
      const regex = new RegExp(`\\b(${this.escapeRegExp(term.term)})\\b(?![^<]*?>)`, 'gi');
      
      processedHtml = processedHtml.replace(regex, (match) => {
        // Wrap the found term with a span that has the tooltip data attribute.
        return `<span class="glossary-term" data-tooltip="${this.escapeHtml(term.definition)}">${match}</span>`;
      });
    });

    return this.sanitizer.bypassSecurityTrustHtml(processedHtml);
  }

  private escapeRegExp(string: string): string {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
  }
  
  private escapeHtml(string: string): string {
    return string
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
}
