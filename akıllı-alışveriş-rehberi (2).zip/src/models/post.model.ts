export type ContentBlock = HtmlBlock | GalleryBlock;

export interface HtmlBlock {
  type: 'html';
  content: string;
}

export interface GalleryBlock {
  type: 'gallery';
  images: string[];
}

export interface Citation {
  type: 'book' | 'article' | 'video';
  title: string;
  authorOrSource: string;
  url?: string;
  isbn?: string; // For books, to potentially link with Google Books Viewer
}

export interface ResearchInfo {
  researchTimeInHours: number;
  citations: Citation[];
}

export interface Post {
  id: number;
  title: string;
  summary: string;
  author: string;
  userEmail: string;
  publicationDate: string;
  tags: string[];
  content: ContentBlock[];
  imageUrl: string;
  research?: ResearchInfo;
}

export interface PostUpdatePayload {
  id: number;
  title: string;
  summary: string;
  imageUrl: string;
  tags: string[];
  content: string; // The raw HTML string from the editor
  research?: ResearchInfo;
}

export interface PostCreatePayload {
  title: string;
  summary: string;
  imageUrl: string;
  tags: string[];
  content: string; // The raw HTML string from the editor
  research?: ResearchInfo;
}