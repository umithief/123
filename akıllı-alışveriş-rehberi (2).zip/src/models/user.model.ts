export interface BloggerApplication {
  reason: string;
  sampleWorkUrl?: string;
  agreedToTerms: boolean;
}

export interface User {
  name: string;
  email: string;
  username: string;
  bio: string;
  joinDate: string;
  password?: string;
  isAdmin?: boolean;
  isVerified?: boolean;
  canCreatePosts?: boolean;
  bloggerRequestStatus?: 'pending' | 'denied';
  bloggerApplication?: BloggerApplication;
  totalLikes: number;
  avatarUrl?: string;
  coverImageUrl?: string;
  twitterUrl?: string;
  linkedinUrl?: string;
  githubUrl?: string;
}