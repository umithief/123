export interface Comment {
  id: number;
  postId: number;
  author: string;
  avatarUrl?: string;
  timestamp: string; // ISO string
  content: string;
  parentId?: number; // for replies
}
