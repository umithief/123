import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UiStateService {
  isZenMode = signal<boolean>(false);

  toggleZenMode(): void {
    this.isZenMode.update(value => !value);
  }

  disableZenMode(): void {
    if (this.isZenMode()) {
        this.isZenMode.set(false);
    }
  }
}
