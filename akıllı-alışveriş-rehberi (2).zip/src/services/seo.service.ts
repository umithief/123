import { Injectable, inject, OnDestroy } from '@angular/core';
import { Title, Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/common';
import { Post } from '../models/post.model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SeoService implements OnDestroy {
  private titleService = inject(Title);
  private metaService = inject(Meta);
  private document = inject(DOCUMENT);
  private router = inject(Router);

  private readonly siteName = 'Akıllı Alışveriş Rehberi';
  private canonicalLinkElement: HTMLLinkElement | null = null;

  updateMetaTagsForPost(post: Post): void {
    const postUrl = `${window.location.origin}${window.location.pathname}#${this.router.url}`;
    
    // 1. Update Title
    this.titleService.setTitle(`${post.title} | ${this.siteName}`);
    
    // 2. Update Standard Meta Tags
    this.metaService.updateTag({ name: 'description', content: post.summary });
    
    // 3. Update Open Graph (Facebook, WhatsApp, etc.) Meta Tags
    this.metaService.updateTag({ property: 'og:title', content: post.title });
    this.metaService.updateTag({ property: 'og:description', content: post.summary });
    this.metaService.updateTag({ property: 'og:image', content: post.imageUrl });
    this.metaService.updateTag({ property: 'og:url', content: postUrl });
    this.metaService.updateTag({ property: 'og:type', content: 'article' });
    
    // 4. Update Twitter Card Meta Tags
    this.metaService.updateTag({ name: 'twitter:card', content: 'summary_large_image' });
    this.metaService.updateTag({ name: 'twitter:title', content: post.title });
    this.metaService.updateTag({ name: 'twitter:description', content: post.summary });
    this.metaService.updateTag({ name: 'twitter:image', content: post.imageUrl });
    
    // 5. Update Canonical URL
    this.updateCanonicalUrl(postUrl);
  }

  private updateCanonicalUrl(url: string): void {
    if (!this.canonicalLinkElement) {
      this.canonicalLinkElement = this.document.createElement('link');
      this.canonicalLinkElement.setAttribute('rel', 'canonical');
      this.document.head.appendChild(this.canonicalLinkElement);
    }
    this.canonicalLinkElement.setAttribute('href', url);
  }

  // Method to clear tags when navigating away, especially the canonical link
  clearMetaTags(): void {
    this.titleService.setTitle(this.siteName); // Reset to default title
    
    // Remove specific tags if needed, or just let the next page's service call overwrite them
    this.metaService.removeTag("name='description'");
    this.metaService.removeTag("property='og:title'");
    this.metaService.removeTag("property='og:description'");
    this.metaService.removeTag("property='og:image'");
    this.metaService.removeTag("property='og:url'");
    this.metaService.removeTag("property='og:type'");
    this.metaService.removeTag("name='twitter:card'");
    this.metaService.removeTag("name='twitter:title'");
    this.metaService.removeTag("name='twitter:description'");
    this.metaService.removeTag("name='twitter:image'");
    
    // Remove the canonical link from the head
    if (this.canonicalLinkElement) {
      this.document.head.removeChild(this.canonicalLinkElement);
      this.canonicalLinkElement = null;
    }
  }
  
  // This helps clean up if the service itself is destroyed, though unlikely for `providedIn: 'root'`
  ngOnDestroy(): void {
    this.clearMetaTags();
  }
}
