import { Injectable, signal, computed } from '@angular/core';
import { Comment } from '../models/comment.model';
import { COMMENTS } from '../data/comment-data';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CommentService {
  private comments = signal<Comment[]>(COMMENTS);

  readonly allComments = computed(() => this.comments());

  getCommentsForPost(postId: number) {
    return computed(() => this.comments().filter(c => c.postId === postId));
  }

  addComment(newCommentData: { postId: number; author: string; content: string; parentId?: number; avatarUrl?: string }): void {
    const newComment: Comment = {
      id: Date.now(), // Use timestamp for unique ID in mock environment
      timestamp: new Date().toISOString(),
      ...newCommentData
    };
    this.comments.update(comments => [...comments, newComment]);
  }

  deleteComment(commentId: number): void {
    this.comments.update(comments => comments.filter(c => c.id !== commentId && c.parentId !== commentId));
  }
}