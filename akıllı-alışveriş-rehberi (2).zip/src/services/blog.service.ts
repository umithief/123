import { Injectable, signal, computed, inject } from '@angular/core';
import { Post, PostUpdatePayload, ContentBlock, HtmlBlock, PostCreatePayload } from '../models/post.model';
import { POSTS } from '../data/blog-data';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class BlogService {
  private authService = inject(AuthService);
  private postsSignal = signal<Post[]>(POSTS);

  // Signals for filtering
  searchTerm = signal<string>('');
  selectedCategory = signal<string | null>(null);

  readonly posts = this.postsSignal.asReadonly();

  // Properties for post editing modal
  isPostEditModalOpen = signal<boolean>(false);
  postToEdit = signal<Post | null>(null);
  
  // Properties for post creation modal
  isPostCreateModalOpen = signal<boolean>(false);

  readonly allCategories = computed(() => {
    const allTags = this.posts().flatMap(p => p.tags);
    return [...new Set(allTags)].sort();
  });

  // Computed signal for filtered posts by category and search term
  readonly filteredPosts = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const category = this.selectedCategory();
    const allPosts = this.posts();

    return allPosts.filter(post => {
      const matchesCategory = category ? post.tags.includes(category) : true;
      
      const postTextContent = post.content
        .filter(block => block.type === 'html')
        .map(block => (block as HtmlBlock).content)
        .join(' ');

      const matchesSearch = term ? 
        post.title.toLowerCase().includes(term) ||
        post.author.toLowerCase().includes(term) ||
        postTextContent.toLowerCase().includes(term) ||
        post.tags.some(tag => tag.toLowerCase().includes(term))
        : true;

      return matchesCategory && matchesSearch;
    });
  });
  
  readonly postsByCurrentUser = computed(() => {
    const currentUser = this.authService.currentUser();
    if (!currentUser) {
      return [];
    }
    return this.posts().filter(p => p.userEmail === currentUser.email);
  });

  constructor() {}
  
  clearFilters(): void {
    this.searchTerm.set('');
    this.selectedCategory.set(null);
  }

  // Method to update search term
  search(term: string): void {
    this.searchTerm.set(term);
  }
  
  // Method to update selected category
  selectCategory(category: string | null): void {
    this.selectedCategory.set(category);
  }

  // Methods for post editing
  openPostEditModal(post: Post): void {
    this.postToEdit.set(post);
    this.isPostEditModalOpen.set(true);
  }

  closePostEditModal(): void {
    this.isPostEditModalOpen.set(false);
    this.postToEdit.set(null);
  }
  
  // Methods for post creation
  openPostCreateModal(): void {
    this.isPostCreateModalOpen.set(true);
  }

  closePostCreateModal(): void {
    this.isPostCreateModalOpen.set(false);
  }
  
  createPost(postData: PostCreatePayload): void {
    const currentUser = this.authService.currentUser();
    if (!currentUser) return;

    const newPost: Post = {
      id: Math.max(0, ...this.posts().map(p => p.id)) + 1,
      title: postData.title,
      summary: postData.summary,
      author: currentUser.name,
      userEmail: currentUser.email,
      publicationDate: new Date().toISOString().split('T')[0], // YYYY-MM-DD
      tags: postData.tags,
      content: [{ type: 'html', content: postData.content }],
      imageUrl: postData.imageUrl,
      research: postData.research,
    };

    this.postsSignal.update(posts => [newPost, ...posts]);
    this.closePostCreateModal();
  }
  
  deletePost(postId: number): void {
    this.postsSignal.update(posts => posts.filter(p => p.id !== postId));
  }

  updatePost(updatedPostData: PostUpdatePayload): void {
    this.postsSignal.update(posts => 
      posts.map(p => {
        if (p.id === updatedPostData.id) {
            // Find the first HTML content block and update it.
            // Leave other blocks (like galleries) untouched.
            const firstHtmlBlockIndex = p.content.findIndex(block => block.type === 'html');
            const newContentBlocks = [...p.content];

            if (firstHtmlBlockIndex !== -1) {
                // Update existing HTML block
                (newContentBlocks[firstHtmlBlockIndex] as HtmlBlock).content = updatedPostData.content;
            } else {
                // If for some reason there was no html block, create one.
                newContentBlocks.unshift({ type: 'html', content: updatedPostData.content });
            }

            return {
                ...p, // keep author, date, etc. from original post
                title: updatedPostData.title,
                summary: updatedPostData.summary,
                imageUrl: updatedPostData.imageUrl,
                tags: updatedPostData.tags,
                content: newContentBlocks,
                research: updatedPostData.research,
            };
        }
        return p;
      })
    );
    this.closePostEditModal();
  }

  public calculateReadingTime(content: ContentBlock[]): number {
    if (!content || content.length === 0) {
      return 0;
    }
    
    const textContent = content
      .filter(block => block.type === 'html')
      .map(block => (block as HtmlBlock).content)
      .join(' ');

    // Strip HTML tags to count only words
    const text = textContent.replace(/<[^>]*>/g, '');
    const wordsPerMinute = 200;
    const words = text.trim().split(/\s+/).length;
    return Math.ceil(words / wordsPerMinute);
  }
}