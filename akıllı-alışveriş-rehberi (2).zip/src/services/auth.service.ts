import { Injectable, signal, computed } from '@angular/core';
import { User, BloggerApplication } from '../models/user.model';

// Mock user database
const MOCK_USERS: User[] = [
  { 
    name: 'Admin User', 
    email: 'admin@example.com', 
    username: 'admin',
    password: 'password123',
    bio: 'Sitenin yöneticisi. Tüm yazıları ve kullanıcıları yönetir.',
    joinDate: '2023-01-15',
    isAdmin: true,
    isVerified: true,
    canCreatePosts: true,
    totalLikes: 12400,
    avatarUrl: 'https://picsum.photos/seed/admin/128/128',
    coverImageUrl: 'https://picsum.photos/seed/admin-cover/1200/400',
    twitterUrl: '#',
    linkedinUrl: '#',
    githubUrl: '#'
  },
  { 
    name: 'Zeynep Tunç', 
    email: 'zeynep.tunc@example.com', 
    username: 'zeyneptunc',
    password: 'password123',
    bio: 'Kişisel finans ve tasarruf yöntemleri üzerine odaklanan bir blogger ve finans danışmanı.',
    joinDate: '2023-05-20',
    canCreatePosts: true,
    isVerified: true,
    totalLikes: 8750,
    avatarUrl: 'https://picsum.photos/seed/zeynep/128/128',
    coverImageUrl: 'https://picsum.photos/seed/zeynep-cover/1200/400',
    twitterUrl: '#',
    linkedinUrl: '#',
    githubUrl: '#'
  },
  {
    name: 'Elif Kara',
    email: 'elif.kara@example.com',
    username: 'elifkara',
    password: 'password123',
    bio: 'Yapay zeka ve teknoloji trendleri üzerine yazan bir teknoloji analisti. Geleceği bugünden anlamaya çalışıyor.',
    joinDate: '2023-03-10',
    canCreatePosts: true,
    isVerified: true,
    totalLikes: 15200,
    avatarUrl: 'https://picsum.photos/seed/elif/128/128',
    coverImageUrl: 'https://picsum.photos/seed/elif-cover/1200/400',
    twitterUrl: '#',
    linkedinUrl: '#',
    githubUrl: '#'
  },
  {
    name: 'Barış Cengiz',
    email: 'baris.cengiz@example.com',
    username: 'bariscengiz',
    password: 'password123',
    bio: 'Dijital dünyada anlamlı bir yaşam sürmenin yollarını araştıran bir yaşam tarzı yazarı.',
    joinDate: '2023-09-01',
    canCreatePosts: true,
    isVerified: true,
    totalLikes: 4300,
    avatarUrl: 'https://picsum.photos/seed/baris/128/128',
    coverImageUrl: 'https://picsum.photos/seed/baris-cover/1200/400',
    twitterUrl: '#',
    linkedinUrl: '#',
    githubUrl: '#'
  },
  {
    name: 'Selin Gezgin',
    email: 'selin.gezgin@example.com',
    username: 'selingezgin',
    password: 'password123',
    bio: 'Selin, dünyayı sırt çantasıyla dolaşan bir macera tutkunu ve bütçe dostu seyahat uzmanı.',
    joinDate: '2023-02-28',
    canCreatePosts: true,
    isVerified: true,
    totalLikes: 22800,
    avatarUrl: 'https://picsum.photos/seed/selin/128/128',
    coverImageUrl: 'https://picsum.photos/seed/selin-cover/1200/400',
    twitterUrl: '#',
    linkedinUrl: '#',
    githubUrl: '#'
  },
  {
    name: 'Ahmet Kodlar',
    email: 'ahmet.kodlar@example.com',
    username: 'ahmetkodlar',
    password: 'password123',
    bio: 'Yazılım geliştirme ve temiz kod prensipleri üzerine odaklanmış bir yazılım mühendisi.',
    joinDate: '2023-06-12',
    canCreatePosts: true,
    isVerified: true,
    totalLikes: 18600,
    avatarUrl: 'https://picsum.photos/seed/ahmet/128/128',
    coverImageUrl: 'https://picsum.photos/seed/ahmet-cover/1200/400',
    twitterUrl: '#',
    linkedinUrl: '#',
    githubUrl: '#'
  },
  {
    name: 'Yeni Admin',
    email: '11@11',
    username: 'yeniadmin',
    password: '123',
    bio: 'Yeni oluşturulmuş admin hesabı.',
    joinDate: '2024-08-11',
    isAdmin: true,
    isVerified: true,
    canCreatePosts: true,
    totalLikes: 0,
    avatarUrl: 'https://picsum.photos/seed/yeniadmin/128/128',
    coverImageUrl: 'https://picsum.photos/seed/yeniadmin-cover/1200/400',
    twitterUrl: '#',
    linkedinUrl: '#',
    githubUrl: '#'
  },
  {
    name: 'Başvuru Yapan Kullanıcı',
    email: 'basvuru@mail.com',
    username: 'basvuran',
    password: '123',
    bio: 'Yazar olmak için başvurdum.',
    joinDate: '2024-08-12',
    canCreatePosts: false,
    isVerified: false,
    bloggerRequestStatus: 'pending',
    bloggerApplication: {
      reason: 'Platformunuzun kalitesini çok beğeniyorum ve teknoloji alanındaki bilgi birikimimi okuyucularınızla paylaşmak istiyorum. Özellikle yapay zeka ve yazılım geliştirme konularında özgün içerikler üretebilirim.',
      sampleWorkUrl: 'https://medium.com/@my-best-article',
      agreedToTerms: true,
    },
    totalLikes: 10,
    avatarUrl: 'https://picsum.photos/seed/applicant/128/128',
    coverImageUrl: 'https://picsum.photos/seed/applicant-cover/1200/400',
  }
];

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private users = signal<User[]>(MOCK_USERS);
  currentUser = signal<User | null>(null);
  
  // Expose all users for admin panel
  readonly allUsers = computed(() => this.users());

  // Mock login functionality
  login(email: string, password: string): 'USER_NOT_FOUND' | 'INVALID_PASSWORD' | 'SUCCESS' {
    const user = this.users().find(u => u.email.toLowerCase() === email.trim().toLowerCase());

    if (!user) {
      return 'USER_NOT_FOUND';
    }

    if (user.password !== password) {
      return 'INVALID_PASSWORD';
    }
    
    this.currentUser.set(user);
    return 'SUCCESS';
  }

  // Mock registration functionality
  register(name: string, email: string, password: string): 'EMAIL_EXISTS' | 'SUCCESS' {
    if (this.users().some(u => u.email.toLowerCase() === email.trim().toLowerCase())) {
        return 'EMAIL_EXISTS';
    }
    const newUser: User = { 
      name, 
      email: email.trim(), 
      username: email.split('@')[0],
      bio: 'Yeni üye! Biyografinizi düzenleyebilirsiniz.', 
      joinDate: new Date().toISOString().split('T')[0],
      password,
      canCreatePosts: false,
      isVerified: false,
      totalLikes: 0,
      avatarUrl: `https://picsum.photos/seed/${email.trim()}/128/128`,
      coverImageUrl: `https://picsum.photos/seed/${email.trim()}-cover/1200/400`
    };
    this.users.update(users => [...users, newUser]);
    this.currentUser.set(newUser);
    return 'SUCCESS';
  }

  logout(): void {
    this.currentUser.set(null);
  }

  updateUser(updatedData: Partial<User>): void {
    const currentUser = this.currentUser();
    if (currentUser) {
      const userToUpdate = { ...currentUser, ...updatedData };
      this.currentUser.set(userToUpdate);
      this.users.update(users => 
        users.map(u => u.email === currentUser.email ? { ...u, ...updatedData } : u)
      );
    }
  }
  
  getUserByEmail(email: string): User | undefined {
    return this.users().find(u => u.email === email);
  }

  getUserByName(name: string): User | undefined {
    return this.users().find(u => u.name === name);
  }
  
  deleteUser(email: string): void {
    this.users.update(users => users.filter(u => u.email !== email));
  }
  
  togglePostCreationPermission(email: string): void {
    this.users.update(users =>
      users.map(user =>
        user.email === email && !user.isAdmin
          ? { ...user, canCreatePosts: !user.canCreatePosts }
          : user
      )
    );
  }
  
  requestBloggerStatus(application: BloggerApplication): void {
    const user = this.currentUser();
    if (!user || user.canCreatePosts || user.isAdmin) return;
    
    const updatedUser = { ...user, bloggerRequestStatus: 'pending' as const, bloggerApplication: application };
    
    // Update current user signal
    this.currentUser.set(updatedUser);
    
    // Update main user list
    this.users.update(users =>
      users.map(u => u.email === user.email ? updatedUser : u)
    );
  }

  approveBloggerRequest(email: string): void {
    let approvedUser: User | null = null;
    this.users.update(users =>
      users.map(user => {
        if (user.email === email) {
          approvedUser = { 
            ...user, 
            canCreatePosts: true, 
            bloggerRequestStatus: undefined, 
            bloggerApplication: undefined 
          };
          return approvedUser;
        }
        return user;
      })
    );

    // If by any chance the current user is the one being approved, update their signal
    if (this.currentUser()?.email === email && approvedUser) {
      this.currentUser.set(approvedUser);
    }
  }

  denyBloggerRequest(email: string): void {
    let deniedUser: User | null = null;
    this.users.update(users =>
      users.map(user => {
        if (user.email === email) {
          deniedUser = { 
            ...user, 
            bloggerRequestStatus: 'denied', 
            bloggerApplication: undefined 
          };
          return deniedUser;
        }
        return user;
      })
    );
    
    // If by any chance the current user is the one being denied, update their signal
    if (this.currentUser()?.email === email && deniedUser) {
      this.currentUser.set(deniedUser);
    }
  }
}