import { Injectable, signal } from '@angular/core';

export interface GlossaryTerm {
  term: string;
  definition: string;
}

@Injectable({
  providedIn: 'root'
})
export class GlossaryService {

  private glossaryTerms = signal<GlossaryTerm[]>([
    {
      term: 'Yapay Zeka',
      definition: 'İnsan zekasını taklit ederek görevleri yerine getiren ve topladığı bilgilere göre kendini geliştirebilen sistemler veya makineler.'
    },
    {
      term: 'Minimalizm',
      definition: 'Sadelik ve nesnelliği ön plana çıkaran, daha az eşya veya unsurla daha fazlasını başarmayı hedefleyen bir yaşam felsefesi veya sanat akımı.'
    },
    {
      term: 'Programlama',
      definition: 'Bir bilgisayara veya cihaza belirli görevleri yerine getirmesi için komutlar dizisi yazma süreci.'
    },
    {
      term: 'Teknoloji',
      definition: 'Mal ve hizmetlerin üretiminde veya bunlara yönelik amaçların gerçekleştirilmesinde kullanılan beceriler, yöntemler, süreçler, teknikler bütünü.'
    },
    {
      term: 'SEO',
      definition: 'Açılımı "Search Engine Optimization" (Arama Motoru Optimizasyonu) olan, web sitelerinin arama motoru sonuçlarında daha üst sıralarda yer almasını sağlayan teknik ve stratejiler bütünüdür.'
    }
  ]);

  getTerms() {
    return this.glossaryTerms();
  }
}
