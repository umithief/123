import { Injectable, signal, inject, effect } from '@angular/core';
import { AuthService } from './auth.service';

interface StreakData {
  count: number;
  lastVisit: string; // YYYY-MM-DD
}

@Injectable({
  providedIn: 'root',
})
export class ReadingStreakService {
  private authService = inject(AuthService);
  
  streakCount = signal(0);
  isStreakActive = signal(false);
  showCelebration = signal(false);

  private readonly STORAGE_KEY_PREFIX = 'reading_streak_';

  constructor() {
    effect(() => {
      const user = this.authService.currentUser();
      if (user) {
        this.checkAndUpdateStreak();
      } else {
        // Reset when user logs out
        this.streakCount.set(0);
        this.isStreakActive.set(false);
        this.showCelebration.set(false);
      }
    });
  }

  private checkAndUpdateStreak(): void {
    const currentUser = this.authService.currentUser();
    if (!currentUser) return;

    const storageKey = `${this.STORAGE_KEY_PREFIX}${currentUser.email}`;
    const storedData = localStorage.getItem(storageKey);
    const today = new Date();
    const todayStr = this.toDateString(today);

    let streakData: StreakData;

    if (storedData) {
      streakData = JSON.parse(storedData);
      const lastVisitDate = new Date(streakData.lastVisit);
      
      const isToday = this.toDateString(lastVisitDate) === todayStr;
      
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const isYesterday = this.toDateString(lastVisitDate) === this.toDateString(yesterday);
      
      if (isToday) {
        // Already visited today, do nothing
        this.streakCount.set(streakData.count);
        this.isStreakActive.set(true);
        return;
      } else if (isYesterday) {
        // Visited yesterday, increment streak
        streakData.count++;
        streakData.lastVisit = todayStr;
        this.celebrateMilestone(streakData.count);
      } else {
        // Missed a day, reset streak
        streakData.count = 1;
        streakData.lastVisit = todayStr;
      }
    } else {
      // First visit
      streakData = { count: 1, lastVisit: todayStr };
    }
    
    localStorage.setItem(storageKey, JSON.stringify(streakData));
    this.streakCount.set(streakData.count);
    this.isStreakActive.set(true);
  }

  private celebrateMilestone(streak: number): void {
    if (streak === 7) {
      this.showCelebration.set(true);
    }
  }

  private toDateString(date: Date): string {
    return date.toISOString().split('T')[0];
  }
}
