import { Injectable, signal } from '@angular/core';

export interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error';
}

@Injectable({
  providedIn: 'root',
})
export class ToastService {
  toasts = signal<Toast[]>([]);

  show(message: string, type: 'success' | 'error' = 'success'): void {
    const newToast: Toast = {
      id: Date.now(),
      message,
      type,
    };
    
    this.toasts.update(currentToasts => [...currentToasts, newToast]);

    setTimeout(() => this.remove(newToast.id), 3500);
  }

  remove(id: number): void {
    this.toasts.update(currentToasts => 
      currentToasts.filter(toast => toast.id !== id)
    );
  }
}