import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ModalService {
  isAuthModalOpen = signal<boolean>(false);
  authModalView = signal<'login' | 'register'>('login');
  isBloggerApplicationModalOpen = signal<boolean>(false);

  openAuthModal(view: 'login' | 'register'): void {
    this.authModalView.set(view);
    this.isAuthModalOpen.set(true);
  }

  closeAuthModal(): void {
    this.isAuthModalOpen.set(false);
  }

  openBloggerApplicationModal(): void {
    this.isBloggerApplicationModalOpen.set(true);
  }

  closeBloggerApplicationModal(): void {
    this.isBloggerApplicationModalOpen.set(false);
  }
}