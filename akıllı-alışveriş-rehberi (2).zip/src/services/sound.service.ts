import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class SoundService {
  private platformId = inject(PLATFORM_ID);
  private clickSound!: HTMLAudioElement;
  private toggleSound!: HTMLAudioElement;

  // Simple, short, royalty-free WAV sounds encoded in base64
  private readonly CLICK_SOUND_SRC = 'data:audio/wav;base64,UklGRiYAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQQAAAAkAAAA/wAA//8A/wAAAP8A/wD/AP8A/wAA//8A/wAAAP8A/wAAAP8A';
  private readonly TOGGLE_SOUND_SRC = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQQAAAAMAAD/AP8A/wD///8A/wD/AP8A/wA=';

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.clickSound = new Audio(this.CLICK_SOUND_SRC);
      this.clickSound.volume = 0.2; // 20% volume as requested

      this.toggleSound = new Audio(this.TOGGLE_SOUND_SRC);
      this.toggleSound.volume = 0.2; // 20% volume as requested
    }
  }

  private playSound(audio: HTMLAudioElement): void {
    if (isPlatformBrowser(this.platformId) && audio) {
      // Rewind to the start to allow for rapid playback
      audio.currentTime = 0;
      audio.play().catch(error => {
        // Autoplay can be blocked by browsers, so we catch the error.
        // This is less of an issue since sounds are triggered by user interaction.
        console.error("Sound playback failed. This might be due to browser autoplay policies.", error);
      });
    }
  }

  playClickSound(): void {
    this.playSound(this.clickSound);
  }

  playToggleSound(): void {
    this.playSound(this.toggleSound);
  }
}
