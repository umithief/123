import { Component, ChangeDetectionStrategy, signal, effect, Renderer2, inject, PLATFORM_ID, ViewChild, ElementRef } from '@angular/core';
import { isPlatformBrowser, CommonModule, DOCUMENT, NgOptimizedImage } from '@angular/common';
import { Router, RouterOutlet, RouterLink, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { filter } from 'rxjs/operators';
import { ReadingProgressComponent } from './components/reading-progress/reading-progress.component';
import { AuthModalComponent } from './components/auth-modal/auth-modal.component';
import { AuthService } from './services/auth.service';
import { BlogService } from './services/blog.service';
import { PostEditModalComponent } from './components/post-edit-modal/post-edit-modal.component';
import { Post, PostUpdatePayload, PostCreatePayload } from './models/post.model';
import { ModalService } from './services/modal.service';
import { LoadingService } from './services/loading.service';
import { LoadingBarComponent } from './components/loading-bar/loading-bar.component';
import { UiStateService } from './services/ui-state.service';
import { SoundService } from './services/sound.service';
import { SearchOverlayComponent } from './app/components/search-overlay/search-overlay.component';
import { CookieConsentComponent } from './components/animated-image/cookie-consent.component';
import { PostCreateModalComponent } from './components/post-create-modal/post-create-modal.component';
import { ImageOptimizerPipe } from './app/pipes/image-optimizer.pipe';
import { ToastService } from './services/toast.service';
import { BloggerApplicationModalComponent } from './components/blogger-application-modal/blogger-application-modal.component';
import { BloggerApplication } from './models/user.model';
import { ReadingStreakComponent } from './app/components/reading-streak/reading-streak.component';
import { ConfettiComponent } from './app/components/confetti/confetti.component';
import { ReadingStreakService } from './services/reading-streak.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RouterOutlet, RouterLink, ReadingProgressComponent, AuthModalComponent, PostEditModalComponent, PostCreateModalComponent, LoadingBarComponent, SearchOverlayComponent, CookieConsentComponent, NgOptimizedImage, ImageOptimizerPipe, BloggerApplicationModalComponent, ReadingStreakComponent, ConfettiComponent],
  // FIX: Moved HostListeners to the component's host object as per best practices.
  host: {
    '(window:scroll)': 'onWindowScroll()',
    '(document:keydown.escape)': 'onKeydownHandler($event)',
    '(document:click)': 'onDocumentClick($event)',
    '(document:visibilitychange)': 'onVisibilityChange()',
  }
})
export class AppComponent {
  // FIX: Explicitly typing injected services to resolve errors where properties did not exist on type 'unknown'.
  private renderer: Renderer2 = inject(Renderer2);
  private platformId: object = inject(PLATFORM_ID);
  private router: Router = inject(Router);
  private titleService: Title = inject(Title);
  private document: Document = inject(DOCUMENT);
  authService: AuthService = inject(AuthService);
  blogService: BlogService = inject(BlogService);
  modalService: ModalService = inject(ModalService);
  toastService: ToastService = inject(ToastService);
  private loadingService: LoadingService = inject(LoadingService);
  private uiStateService: UiStateService = inject(UiStateService);
  private soundService: SoundService = inject(SoundService);
  private readingStreakService = inject(ReadingStreakService);

  private originalTitle: string = '';
  private awayMessages: string[] = ['Burası çok sessiz... 🥺', 'Okumaya devam et 👀'];

  isDarkMode = signal<boolean>(false);
  isMobileMenuOpen = signal<boolean>(false);
  navScrolled = signal<boolean>(false);
  isSearchOverlayOpen = signal(false);
  isZenMode = this.uiStateService.isZenMode;

  // Auth signals from service
  currentUser = this.authService.currentUser;
  isAuthModalOpen = this.modalService.isAuthModalOpen;
  authModalView = this.modalService.authModalView;
  isProfileMenuOpen = signal(false);
  isCategoryMenuOpen = signal(false);

  // Signals for Post Edit Modal
  isPostEditModalOpen = this.blogService.isPostEditModalOpen;
  postToEdit = this.blogService.postToEdit;
  
  // Signals for Post Create Modal
  isPostCreateModalOpen = this.blogService.isPostCreateModalOpen;

  // Blogger Application Modal from service
  isBloggerApplicationModalOpen = this.modalService.isBloggerApplicationModalOpen;

  // Toasts
  toasts = this.toastService.toasts;

  // Reading Streak
  showCelebration = this.readingStreakService.showCelebration;

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        this.isDarkMode.set(true);
      } else {
        this.isDarkMode.set(false);
      }
    }

    effect(() => {
      if (isPlatformBrowser(this.platformId)) {
        if (this.isDarkMode()) {
          this.renderer.addClass(document.documentElement, 'dark');
          localStorage.setItem('theme', 'dark');
        } else {
          this.renderer.removeClass(document.documentElement, 'dark');
          localStorage.setItem('theme', 'light');
        }
      }
    });

    // Router events for loading bar
    this.router.events.pipe(
      filter(event => 
        event instanceof NavigationStart ||
        event instanceof NavigationEnd ||
        event instanceof NavigationCancel ||
        event instanceof NavigationError
      )
    ).subscribe(event => {
      if (event instanceof NavigationStart) {
        this.loadingService.show();
      } else { // End, Cancel, Error
        this.loadingService.hide();
      }
    });
  }

  onVisibilityChange(): void {
    if (isPlatformBrowser(this.platformId)) {
      if (this.document.hidden) {
        this.originalTitle = this.titleService.getTitle();
        const randomIndex = Math.floor(Math.random() * this.awayMessages.length);
        this.titleService.setTitle(this.awayMessages[randomIndex]);
      } else {
        if (this.originalTitle) {
          this.titleService.setTitle(this.originalTitle);
        }
      }
    }
  }

  onWindowScroll(): void {
    if (isPlatformBrowser(this.platformId)) {
      const scrollY = window.scrollY;
      this.navScrolled.set(scrollY > 10);
    }
  }
  
  onKeydownHandler(event: KeyboardEvent) {
    if (this.isSearchOverlayOpen()) {
      this.closeSearchOverlay();
      return;
    }
    if (this.isZenMode()) {
      this.uiStateService.disableZenMode();
      return; // Prioritize exiting zen mode
    }
     if (this.isProfileMenuOpen()) {
      this.isProfileMenuOpen.set(false);
    }
    if (this.isCategoryMenuOpen()) {
      this.isCategoryMenuOpen.set(false);
    }
    if (this.isAuthModalOpen()) {
      this.closeAuthModal();
    }
    if (this.isBloggerApplicationModalOpen()) {
      this.modalService.closeBloggerApplicationModal();
    }
  }

  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;

    // Play click sound on interactive elements
    if (target.closest('a, button, [routerLink], [role="button"]')) {
      this.soundService.playClickSound();
    }

    if (this.isProfileMenuOpen() && !target.closest('.profile-menu-trigger')) {
      this.isProfileMenuOpen.set(false);
    }
    if (this.isCategoryMenuOpen() && !target.closest('.category-menu-trigger')) {
      this.isCategoryMenuOpen.set(false);
    }
  }

  toggleDarkMode(): void {
    this.isDarkMode.update(value => !value);
    this.soundService.playToggleSound();
  }

  toggleMobileMenu(): void {
    this.isMobileMenuOpen.update(value => !value);
  }

  openSearchOverlay(): void {
    this.isSearchOverlayOpen.set(true);
  }
  
  closeSearchOverlay(): void {
    this.isSearchOverlayOpen.set(false);
    // Clear search term when closing the overlay
    this.blogService.search('');
  }

  // Auth methods
  openAuthModal(view: 'login' | 'register'): void {
    this.modalService.openAuthModal(view);
    this.isMobileMenuOpen.set(false); // Close mobile menu if open
  }

  closeAuthModal(): void {
    this.modalService.closeAuthModal();
  }

  toggleProfileMenu(): void {
    this.isCategoryMenuOpen.set(false);
    this.isProfileMenuOpen.update(v => !v);
  }

  toggleCategoryMenu(): void {
    this.isProfileMenuOpen.set(false);
    this.isCategoryMenuOpen.update(v => !v);
  }

  // New method for user profile
  openUserProfile(): void {
    this.router.navigate(['/profile']);
    this.isProfileMenuOpen.set(false);
  }

  logout(): void {
    this.authService.logout();
    this.isProfileMenuOpen.set(false);
    this.router.navigate(['/']);
  }

  goHome(): void {
    this.blogService.clearFilters();
    this.router.navigate(['/']);
  }

  selectCategoryAndGoHome(category: string): void {
    this.blogService.selectCategory(category);
    this.router.navigate(['/']);
    this.isCategoryMenuOpen.set(false);
    this.isMobileMenuOpen.set(false);
  }

  // Post Edit Modal handlers
  handleClosePostEditModal(): void {
    this.blogService.closePostEditModal();
  }

  handleSavePost(postData: PostUpdatePayload): void {
    this.blogService.updatePost(postData);
  }
  
  // Post Create Modal handlers
  openPostCreateModal(): void {
    this.blogService.openPostCreateModal();
    this.isProfileMenuOpen.set(false);
  }
  
  handleClosePostCreateModal(): void {
    this.blogService.closePostCreateModal();
  }

  handleCreatePost(postData: PostCreatePayload): void {
    this.blogService.createPost(postData);
  }

  // Blogger Application handlers
  openBloggerApplicationModal(): void {
    this.modalService.openBloggerApplicationModal();
    this.isProfileMenuOpen.set(false);
  }

  handleSubmitBloggerApplication(application: BloggerApplication): void {
    this.authService.requestBloggerStatus(application);
    this.modalService.closeBloggerApplicationModal();
    this.toastService.show('Başvurunuz başarıyla gönderildi!');
  }
}