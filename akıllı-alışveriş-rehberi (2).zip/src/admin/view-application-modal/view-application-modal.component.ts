import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { User } from '../../models/user.model';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';

@Component({
  selector: 'app-view-application-modal',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage, ImageOptimizerPipe],
  templateUrl: '../../app/components/search-overlay/view-application-modal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ViewApplicationModalComponent {
  user = input.required<User>();
  closeModal = output<void>();
  approve = output<string>();
  deny = output<string>();

  onClose(): void {
    this.closeModal.emit();
  }

  onApprove(): void {
    this.approve.emit(this.user().email);
  }

  onDeny(): void {
    this.deny.emit(this.user().email);
  }
}