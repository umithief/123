import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { CommentService } from '../../services/comment.service';
import { TimeAgoPipe } from '../../pipes/time-ago.pipe';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-admin-comments',
  standalone: true,
  imports: [CommonModule, TimeAgoPipe, NgOptimizedImage, ImageOptimizerPipe],
  templateUrl: './admin-comments.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminCommentsComponent {
  private commentService = inject(CommentService);
  private toastService = inject(ToastService);
  comments = this.commentService.allComments;

  deleteComment(commentId: number): void {
    if (confirm('Bu yorumu ve altındaki yanıtları silmek istediğinizden emin misiniz?')) {
      this.commentService.deleteComment(commentId);
      this.toastService.show('Yorum başarıyla silindi.', 'success');
    }
  }
}