import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { BlogService } from '../../services/blog.service';
import { Post } from '../../models/post.model';

@Component({
  selector: 'app-admin-posts',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './admin-posts.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminPostsComponent {
  private blogService = inject(BlogService);
  posts = this.blogService.posts;

  editPost(post: Post): void {
    this.blogService.openPostEditModal(post);
  }

  deletePost(postId: number): void {
    if (confirm('Bu yazıyı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.')) {
      this.blogService.deletePost(postId);
    }
  }
  
  createNewPost(): void {
    this.blogService.openPostCreateModal();
  }
}