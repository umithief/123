import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';
import { User } from '../../models/user.model';
import { ViewApplicationModalComponent } from '../view-application-modal/view-application-modal.component';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage, ImageOptimizerPipe, ViewApplicationModalComponent],
  templateUrl: './admin-users.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminUsersComponent {
  private authService = inject(AuthService);
  private toastService = inject(ToastService);
  users = this.authService.allUsers;
  currentUser = this.authService.currentUser;

  isViewApplicationModalOpen = signal(false);
  userToView = signal<User | null>(null);

  viewApplication(user: User): void {
    this.userToView.set(user);
    this.isViewApplicationModalOpen.set(true);
  }

  deleteUser(email: string): void {
    if (this.currentUser()?.email === email) {
      this.toastService.show('Kendinizi silemezsiniz.', 'error');
      return;
    }
    if (confirm('Bu kullanıcıyı silmek istediğinizden emin misiniz?')) {
      const userToDelete = this.users().find(u => u.email === email);
      this.authService.deleteUser(email);
      if (userToDelete) {
        this.toastService.show(`${userToDelete.name} adlı kullanıcı başarıyla silindi.`, 'success');
      }
    }
  }

  togglePostPermission(email: string): void {
    const user = this.users().find(u => u.email === email);
    if (user) {
      // Determine what the new state will be to craft the message correctly
      const willHavePermission = !user.canCreatePosts;
      this.authService.togglePostCreationPermission(email);
      const message = willHavePermission
        ? `${user.name} adlı kullanıcıya yazı yetkisi verildi.`
        : `${user.name} adlı kullanıcının yazı yetkisi kaldırıldı.`;
      this.toastService.show(message, 'success');
    }
  }

  approveRequest(email: string): void {
    if(confirm('Bu kullanıcıya yazar yetkisi vermek istediğinizden emin misiniz?')) {
      this.authService.approveBloggerRequest(email);
      const user = this.users().find(u => u.email === email);
      this.toastService.show(`${user?.name} adlı kullanıcının başvurusu onaylandı.`, 'success');
    }
  }

  denyRequest(email: string): void {
    if(confirm('Bu kullanıcının yazar olma isteğini reddetmek istediğinizden emin misiniz?')) {
      this.authService.denyBloggerRequest(email);
      const user = this.users().find(u => u.email === email);
      this.toastService.show(`${user?.name} adlı kullanıcının başvurusu reddedildi.`);
    }
  }

  handleApproveFromModal(email: string): void {
    this.authService.approveBloggerRequest(email);
    const user = this.users().find(u => u.email === email);
    this.toastService.show(`${user?.name} adlı kullanıcının başvurusu onaylandı.`, 'success');
    this.isViewApplicationModalOpen.set(false);
  }

  handleDenyFromModal(email: string): void {
    this.authService.denyBloggerRequest(email);
    const user = this.users().find(u => u.email === email);
    this.toastService.show(`${user?.name} adlı kullanıcının başvurusu reddedildi.`);
    this.isViewApplicationModalOpen.set(false);
  }
}