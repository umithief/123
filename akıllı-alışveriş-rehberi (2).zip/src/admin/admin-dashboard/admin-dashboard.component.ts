import { Component, ChangeDetectionStrategy, inject, computed } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { BlogService } from '../../services/blog.service';
import { CommentService } from '../../services/comment.service';
import { AuthService } from '../../services/auth.service';
import { RouterLink } from '@angular/router';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';

@Component({
  selector: 'app-admin-dashboard',
  imports: [CommonModule, RouterLink, NgOptimizedImage, ImageOptimizerPipe],
  templateUrl: './admin-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDashboardComponent {
  private blogService = inject(BlogService);
  private commentService = inject(CommentService);
  private authService = inject(AuthService);

  stats = computed(() => ({
    totalPosts: this.blogService.posts().length,
    totalComments: this.commentService.allComments().length,
    totalUsers: this.authService.allUsers().length,
  }));

  recentPosts = computed(() => this.blogService.posts().slice(0, 5));
  recentComments = computed(() => this.commentService.allComments().slice().reverse().slice(0, 5));
}
