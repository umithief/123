import { Component, ChangeDetectionStrategy, computed, inject, input, signal, ViewChild, ElementRef } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { CommentService } from '../../services/comment.service';
import { AuthService } from '../../services/auth.service';
import { TimeAgoPipe } from '../../pipes/time-ago.pipe';
import { ModalService } from '../../services/modal.service';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';


@Component({
  selector: 'app-comment-section',
  templateUrl: './comment-section.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, TimeAgoPipe, NgOptimizedImage, ImageOptimizerPipe]
})
export class CommentSectionComponent {
  postId = input.required<number>();
  
  private commentService = inject(CommentService);
  private authService = inject(AuthService);
  private modalService = inject(ModalService);
  private fb = inject(FormBuilder);
  private sanitizer = inject(DomSanitizer);
  
  @ViewChild('commentEditor') commentEditor!: ElementRef<HTMLDivElement>;

  currentUser = this.authService.currentUser;
  
  commentsForPost = computed(() => {
    const allComments = this.commentService.getCommentsForPost(this.postId())();
    const rootComments = allComments.filter(c => !c.parentId);
    
    return rootComments.map(comment => ({
      ...comment,
      replies: allComments.filter(reply => reply.parentId === comment.id)
                          .sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    })).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  });
  
  totalCommentsCount = computed(() => {
    return this.commentsForPost().reduce((acc, c) => acc + 1 + c.replies.length, 0);
  });

  isInputFocused = signal(false);
  replyToId = signal<number | null>(null);

  commentForm = this.fb.group({
    content: ['', Validators.required]
  });

  // --- Avatar Logic ---
  private colorCache: { [key: string]: string } = {};
  private colors = [ '#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899' ];

  getInitials(name: string): string {
    if (!name) return '';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }

  getAvatarColor(name: string): string {
    if (this.colorCache[name]) {
      return this.colorCache[name];
    }
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    const color = this.colors[Math.abs(hash) % this.colors.length];
    this.colorCache[name] = color;
    return color;
  }
  
  // --- Form Logic ---
  onFocus(): void {
    if (this.currentUser()) {
        this.isInputFocused.set(true);
    } else {
        this.modalService.openAuthModal('login');
    }
  }
  
  onBlur(): void {
    // A small timeout to allow click on submit button or toolbar
    setTimeout(() => {
      if (this.commentEditor && this.commentEditor.nativeElement.innerHTML.trim() === '') {
        this.isInputFocused.set(false);
        this.replyToId.set(null); // Also cancel reply on blur if empty
      }
    }, 200);
  }

  onContentChange(): void {
    if (this.commentEditor) {
      const content = this.commentEditor.nativeElement.innerHTML;
      this.commentForm.controls.content.setValue(content);
      this.commentForm.controls.content.markAsDirty();
      this.commentForm.controls.content.markAsTouched();
    }
  }

  formatDoc(command: string, value: string | null = null): void {
    document.execCommand(command, false, value);
    this.commentEditor.nativeElement.focus();
    this.onContentChange(); // Update form value after formatting
  }

  createLink(): void {
    const url = prompt('Link URL\'sini girin:');
    if (url) {
      this.formatDoc('createLink', url);
    }
  }

  sanitizeAndTrust(html: string): SafeHtml {
    // In a real-world app, use a more robust library like DOMPurify for user-generated content.
    // For this context, we'll trust the basic HTML from our simple editor.
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }

  startReply(commentId: number): void {
    this.replyToId.set(commentId);
    this.isInputFocused.set(true);
    setTimeout(() => this.commentEditor.nativeElement.focus(), 0);
  }
  
  cancelReply(): void {
    this.replyToId.set(null);
    if (!this.commentForm.value.content || this.commentForm.value.content.trim() === '') {
        this.isInputFocused.set(false);
    }
  }

  onSubmit(): void {
    const content = this.commentForm.controls.content.value;
    if (!content || content.trim() === '') {
      return;
    }
    
    const currentUser = this.currentUser();
    if (!currentUser) {
        this.modalService.openAuthModal('login');
        return;
    };
    
    this.commentService.addComment({
      postId: this.postId(),
      author: currentUser.name,
      content: content,
      parentId: this.replyToId() ?? undefined,
      avatarUrl: currentUser.avatarUrl
    });

    this.commentForm.reset();
    if (this.commentEditor) {
      this.commentEditor.nativeElement.innerHTML = ''; // Clear editor
    }
    this.commentForm.controls.content.setValue('');
    this.replyToId.set(null);
    this.isInputFocused.set(false);
  }
}
