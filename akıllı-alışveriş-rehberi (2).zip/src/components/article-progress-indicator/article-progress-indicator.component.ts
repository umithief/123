import { Component, ChangeDetectionStrategy, input, signal, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

interface HeadingInfo {
  top: number; // Percentage from the top of the article
  element: Element;
}

@Component({
  selector: 'app-article-progress-indicator',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './article-progress-indicator.component.html',
  styleUrls: ['./article-progress-indicator.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(window:scroll)': 'onScroll()',
  }
})
export class ArticleProgressIndicatorComponent implements AfterViewInit, OnDestroy {
  articleElement = input.required<HTMLElement>();

  progress = signal(0);
  headings = signal<HeadingInfo[]>([]);
  activeHeadingIndex = signal(-1);

  private observer!: IntersectionObserver;

  ngAfterViewInit(): void {
    // Use timeout to ensure the article content and its children are fully rendered
    setTimeout(() => {
      this.calculateHeadings();
      this.setupIntersectionObserver();
    }, 100);
  }

  ngOnDestroy(): void {
    if (this.observer) {
      this.observer.disconnect();
    }
  }

  calculateHeadings(): void {
    const article = this.articleElement();
    if (!article) return;

    const headingElements = Array.from(article.querySelectorAll('h2, h3'));
    const articleHeight = article.offsetHeight;

    if (articleHeight > 0) {
      this.headings.set(headingElements.map(el => ({
        top: ( (el as HTMLElement).offsetTop / articleHeight ) * 100,
        element: el
      })));
    }
  }
  
  setupIntersectionObserver(): void {
    // This observer will help to find the "active" heading more efficiently
    const options = {
      root: null, // relative to document viewport
      rootMargin: '-50% 0px -50% 0px', // trigger when heading is in the vertical center
      threshold: 0
    };

    this.observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const intersectingElement = entry.target;
          const index = this.headings().findIndex(h => h.element === intersectingElement);
          if (index !== -1) {
            this.activeHeadingIndex.set(index);
          }
        }
      });
    }, options);

    this.headings().forEach(heading => this.observer.observe(heading.element));
  }

  onScroll(): void {
    const article = this.articleElement();
    if (!article) return;

    const articleRect = article.getBoundingClientRect();
    const viewportHeight = window.innerHeight;

    // The total distance we can scroll through the article
    const scrollableDist = articleRect.height - viewportHeight;
    // How far the top of the article has been scrolled out of view
    const scrolledDist = -articleRect.top;

    let currentProgress = 0;
    if (scrollableDist > 0) {
      currentProgress = (scrolledDist / scrollableDist) * 100;
    } else if (articleRect.bottom < viewportHeight) {
      // If article is shorter than viewport and fully visible
      currentProgress = 100;
    }
    
    // Clamp the progress value between 0 and 100
    this.progress.set(Math.max(0, Math.min(100, currentProgress)));
  }

  scrollToHeading(heading: HeadingInfo): void {
    heading.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}
