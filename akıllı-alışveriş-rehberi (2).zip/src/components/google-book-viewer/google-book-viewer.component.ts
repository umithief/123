import { Component, ChangeDetectionStrategy, input, AfterViewInit, ViewChild, ElementRef, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

declare const google: any; // Google'ın global nesnesini bildir

@Component({
  selector: 'app-google-book-viewer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './google-book-viewer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GoogleBookViewerComponent implements AfterViewInit {
  isbn = input.required<string>();

  @ViewChild('viewerCanvas') viewerCanvas!: ElementRef<HTMLDivElement>;
  
  isLoading = signal(true);
  hasError = signal(false);
  errorMessage = signal('');

  // Static properties to manage script loading across all component instances
  private static scriptLoadingState: 'not-loaded' | 'loading' | 'loaded' | 'error' = 'not-loaded';
  private static onLoadCallbacks: (() => void)[] = [];
  private static onErrorCallbacks: ((error: any) => void)[] = [];

  ngAfterViewInit(): void {
    this.loadGoogleBooksApi().then(() => {
      this.initializeViewerWithCallback();
    }).catch(err => {
      console.error('Failed to load Google Books API', err);
      this.isLoading.set(false);
      this.hasError.set(true);
      this.errorMessage.set('Google Kitaplar API yüklenemedi.');
    });
  }

  private loadGoogleBooksApi(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (GoogleBookViewerComponent.scriptLoadingState === 'loaded') {
        return resolve();
      }
      
      if (GoogleBookViewerComponent.scriptLoadingState === 'loading') {
        GoogleBookViewerComponent.onLoadCallbacks.push(resolve);
        GoogleBookViewerComponent.onErrorCallbacks.push(reject);
        return;
      }
      
      if (GoogleBookViewerComponent.scriptLoadingState === 'error') {
        return reject();
      }

      GoogleBookViewerComponent.scriptLoadingState = 'loading';
      GoogleBookViewerComponent.onLoadCallbacks.push(resolve);
      GoogleBookViewerComponent.onErrorCallbacks.push(reject);
      
      const script = document.createElement('script');
      script.src = 'https://www.google.com/books/jsapi.js';
      script.type = 'text/javascript';
      
      script.onload = () => {
        GoogleBookViewerComponent.scriptLoadingState = 'loaded';
        GoogleBookViewerComponent.onLoadCallbacks.forEach(cb => cb());
        GoogleBookViewerComponent.onLoadCallbacks = [];
        GoogleBookViewerComponent.onErrorCallbacks = [];
      };

      script.onerror = (error) => {
        GoogleBookViewerComponent.scriptLoadingState = 'error';
        console.error('Google Books API script failed to load.', error);
        GoogleBookViewerComponent.onErrorCallbacks.forEach(cb => cb(error));
        GoogleBookViewerComponent.onLoadCallbacks = [];
        GoogleBookViewerComponent.onErrorCallbacks = [];
      };
      
      document.head.appendChild(script);
    });
  }
  
  private initializeViewerWithCallback(): void {
    try {
      google.books.load({ 'language': 'tr' });
      google.books.setOnLoadCallback(() => this.initializeViewer());
    } catch(e) {
      console.error('Error calling google.books.load', e);
      this.isLoading.set(false);
      this.hasError.set(true);
      this.errorMessage.set('Google Kitaplar API başlatılamadı.');
    }
  }

  private initializeViewer(): void {
    if (!this.viewerCanvas) return;
    
    // Görüntüleyici örneğini oluştur
    const viewer = new google.books.DefaultViewer(this.viewerCanvas.nativeElement);
    const isbnCode = `ISBN:${this.isbn()}`;

    // Kitabı yükle ve geri çağırma fonksiyonlarını ayarla
    viewer.load(isbnCode, 
      () => { // notFoundCallback
        this.isLoading.set(false);
        this.hasError.set(true);
        this.errorMessage.set('Bu kitap için önizleme bulunamadı.');
      },
      () => { // successCallback
        this.isLoading.set(false);
        this.hasError.set(false);
      }
    );
  }
}