import { Component, ChangeDetectionStrategy, input, output, inject, OnInit, ViewChild, ElementRef, AfterViewInit, Renderer2 } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators, FormArray, FormGroup } from '@angular/forms';
import { Post, PostUpdatePayload, HtmlBlock, ResearchInfo, Citation } from '../../models/post.model';
import { BlogService } from '../../services/blog.service';

@Component({
  selector: 'app-post-edit-modal',
  templateUrl: './post-edit-modal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule]
})
export class PostEditModalComponent implements OnInit, AfterViewInit {
  private fb: FormBuilder = inject(FormBuilder);
  private blogService: BlogService = inject(BlogService);
  private renderer: Renderer2 = inject(Renderer2);
  
  post = input.required<Post>();
  
  closeModal = output<void>();
  savePost = output<PostUpdatePayload>();

  allCategories = this.blogService.allCategories;
  
  @ViewChild('contentEditor') contentEditor!: ElementRef<HTMLDivElement>;

  editForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    summary: ['', [Validators.required, Validators.maxLength(250)]],
    imageUrl: ['', [Validators.required, Validators.pattern('https?://.+')]],
    category: ['', Validators.required],
    content: ['', Validators.required],
    research: this.fb.group({
      researchTimeInHours: [0, [Validators.min(0)]],
      citations: this.fb.array([])
    })
  });

  get citations(): FormArray {
    return this.editForm.get('research.citations') as FormArray;
  }

  createCitationGroup(citation?: Citation): FormGroup {
    return this.fb.group({
      type: [citation?.type || 'article', Validators.required],
      title: [citation?.title || '', Validators.required],
      authorOrSource: [citation?.authorOrSource || '', Validators.required],
      url: [citation?.url || '', Validators.pattern('https?://.+')]
    });
  }

  addCitation(): void {
    this.citations.push(this.createCitationGroup());
  }

  removeCitation(index: number): void {
    this.citations.removeAt(index);
  }

  ngOnInit(): void {
    const currentPost = this.post();
    if (currentPost) {
      // Find the first HTML block to populate the editor
      const firstHtmlBlock = currentPost.content.find(block => block.type === 'html') as HtmlBlock | undefined;
      const editorContent = firstHtmlBlock ? firstHtmlBlock.content : '';

      this.editForm.patchValue({
        title: currentPost.title,
        summary: currentPost.summary,
        imageUrl: currentPost.imageUrl,
        category: currentPost.tags[0] || '',
        content: editorContent
      });

      if (currentPost.research) {
        this.editForm.get('research.researchTimeInHours')?.setValue(currentPost.research.researchTimeInHours);
        this.citations.clear();
        currentPost.research.citations.forEach(citation => {
          this.citations.push(this.createCitationGroup(citation));
        });
      }
    }
  }

  ngAfterViewInit(): void {
    if (this.contentEditor) {
      this.renderer.setProperty(this.contentEditor.nativeElement, 'innerHTML', this.editForm.controls.content.value || '');
    }
  }

  onContentChange(): void {
    if (this.contentEditor) {
      const content = this.contentEditor.nativeElement.innerHTML;
      this.editForm.controls.content.setValue(content);
      this.editForm.controls.content.markAsTouched();
    }
  }
  
  formatDoc(command: string, value: string | null = null): void {
    document.execCommand(command, false, value);
    this.contentEditor.nativeElement.focus();
    this.onContentChange(); // Update form value after formatting
  }
  
  createLink(): void {
    const url = prompt('Link URL\'sini girin:');
    if (url) {
      this.formatDoc('createLink', url);
    }
  }

  onClose(): void {
    this.closeModal.emit();
  }

  onSubmit(): void {
    this.editForm.markAllAsTouched();
    if (this.editForm.valid) {
      const formValue = this.editForm.getRawValue();
      
      let researchData: ResearchInfo | undefined = undefined;
      if (formValue.research && (formValue.research.researchTimeInHours > 0 || formValue.research.citations.length > 0)) {
         const validCitations = formValue.research.citations.filter((c: any) => c.title && c.authorOrSource);
         if(validCitations.length > 0 || formValue.research.researchTimeInHours > 0) {
            researchData = {
              researchTimeInHours: formValue.research.researchTimeInHours || 0,
              citations: validCitations
            };
         }
      }

      const updatedPostData: PostUpdatePayload = {
        id: this.post().id,
        title: formValue.title!,
        summary: formValue.summary!,
        imageUrl: formValue.imageUrl!,
        tags: [formValue.category!],
        content: formValue.content!,
        research: researchData
      };
      this.savePost.emit(updatedPostData);
    }
  }
}