import { Component, ChangeDetectionStrategy, inject, computed, signal, OnInit } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { BlogService } from '../../services/blog.service';
import { Post } from '../../models/post.model';
import { FeaturedSliderComponent } from '../featured-slider/featured-slider.component';
import { PostListComponent } from '../post-list/post-list.component';
import { MarqueeComponent } from '../marquee/marquee.component';
import { NewsletterBoxComponent } from '../newsletter-box/newsletter-box.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FeaturedSliderComponent, PostListComponent, MarqueeComponent, NewsletterBoxComponent, NgOptimizedImage],
})
export class HomeComponent implements OnInit {
  private blogService = inject(BlogService);

  loading = signal(true);
  posts = this.blogService.filteredPosts;
  allCategories = this.blogService.allCategories;
  selectedCategory = this.blogService.selectedCategory;
  searchTerm = this.blogService.searchTerm;

  featuredPosts = computed(() => this.posts().slice(0, 3));
  regularPosts = computed(() => this.posts().slice(3));

  ngOnInit(): void {
    setTimeout(() => {
      this.loading.set(false);
    }, 1000);
  }

  selectCategory(category: string | null): void {
    this.blogService.selectCategory(category);
  }

  clearFilters(): void {
    this.blogService.clearFilters();
  }
}