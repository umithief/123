import { Component, ChangeDetectionStrategy, output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { BloggerApplication } from '../../models/user.model';

@Component({
  selector: 'app-blogger-application-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './blogger-application-modal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BloggerApplicationModalComponent {
  private fb: FormBuilder = inject(FormBuilder);

  closeModal = output<void>();
  submitApplication = output<BloggerApplication>();

  applicationForm = this.fb.group({
    reason: ['', [Validators.required, Validators.minLength(50)]],
    sampleWorkUrl: ['', [Validators.pattern('https?://.+')]],
    agreedToTerms: [false, [Validators.requiredTrue]],
  });

  onClose(): void {
    this.closeModal.emit();
  }

  onSubmit(): void {
    this.applicationForm.markAllAsTouched();
    if (this.applicationForm.valid) {
      this.submitApplication.emit(this.applicationForm.getRawValue() as BloggerApplication);
    }
  }
}