import { Component, ChangeDetectionStrategy, computed, input, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';

@Component({
  selector: 'app-smart-mosaic-gallery',
  imports: [CommonModule, NgOptimizedImage, ImageOptimizerPipe],
  templateUrl: './smart-mosaic-gallery.component.html',
  styleUrls: ['./smart-mosaic-gallery.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(document:keydown)': 'onKeydownHandler($event)',
  }
})
export class SmartMosaicGalleryComponent {
  images = input.required<string[]>();

  // Lightbox state
  isLightboxOpen = signal(false);
  selectedImageIndex = signal(0);

  currentImage = computed(() => this.images()[this.selectedImageIndex()]);
  
  onKeydownHandler(event: KeyboardEvent) {
    if (this.isLightboxOpen()) {
      event.preventDefault(); // prevent page scroll with arrow keys
      if (event.key === 'Escape') this.closeLightbox();
      if (event.key === 'ArrowLeft') this.prevImage();
      if (event.key === 'ArrowRight') this.nextImage();
    }
  }

  openLightbox(index: number): void {
    this.selectedImageIndex.set(index);
    this.isLightboxOpen.set(true);
  }

  closeLightbox(): void {
    this.isLightboxOpen.set(false);
  }

  nextImage(): void {
    this.selectedImageIndex.update(index => (index + 1) % this.images().length);
  }

  prevImage(): void {
    this.selectedImageIndex.update(index => (index - 1 + this.images().length) % this.images().length);
  }
}
