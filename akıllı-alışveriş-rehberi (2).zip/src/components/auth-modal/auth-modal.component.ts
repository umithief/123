import { Component, ChangeDetectionStrategy, output, inject, signal, input } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-auth-modal',
  templateUrl: './auth-modal.component.html',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AuthModalComponent {
  // FIX: Explicitly type FormBuilder to resolve 'unknown' type from inject().
  // This fixes the error "Property 'group' does not exist on type 'unknown'".
  private fb: FormBuilder = inject(FormBuilder);
  private authService = inject(AuthService);
  
  initialView = input<'login' | 'register'>('login');
  closeModal = output<void>();

  view = signal<'login' | 'register'>('login');
  errorMessage = signal<string | null>(null);

  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]],
  });

  registerForm = this.fb.group({
    name: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]],
  });
  
  ngOnInit(): void {
    this.view.set(this.initialView());
  }

  switchView(newView: 'login' | 'register'): void {
    this.view.set(newView);
    this.errorMessage.set(null);
    this.loginForm.reset();
    this.registerForm.reset();
  }

  onClose(): void {
    this.closeModal.emit();
  }

  onSubmitLogin(): void {
    if (this.loginForm.invalid) {
      this.errorMessage.set('Lütfen tüm alanları doğru bir şekilde doldurun.');
      return;
    }
    const { email, password } = this.loginForm.value;
    const result = this.authService.login(email!, password!);

    if (result === 'SUCCESS') {
      this.onClose();
    } else if (result === 'USER_NOT_FOUND') {
      this.errorMessage.set('Bu e-posta adresiyle kayıtlı bir kullanıcı bulunamadı.');
    } else { // INVALID_PASSWORD
      this.errorMessage.set('Girdiğiniz şifre hatalı. Lütfen tekrar deneyin.');
    }
  }

  onSubmitRegister(): void {
    if (this.registerForm.invalid) {
      this.errorMessage.set('Lütfen tüm alanları doğru bir şekilde doldurun.');
      return;
    }
    const { name, email, password } = this.registerForm.value;
    const result = this.authService.register(name!, email!, password!);
    
    if (result === 'SUCCESS') {
      this.onClose();
    } else { // EMAIL_EXISTS
       this.errorMessage.set('Bu e-posta adresi zaten kullanılıyor. Lütfen giriş yapın.');
    }
  }
}