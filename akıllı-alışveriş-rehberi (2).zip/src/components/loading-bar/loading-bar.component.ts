import { Component, ChangeDetectionStrategy, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingService } from '../../services/loading.service';

@Component({
  selector: 'app-loading-bar',
  template: `
    <div 
      class="loading-bar-container"
      [style.opacity]="opacity()">
      <div 
        class="loading-bar" 
        [style.width.%]="width()">
      </div>
    </div>
  `,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoadingBarComponent {
  private loadingService = inject(LoadingService);
  
  width = signal(0);
  opacity = signal(0);
  private completionTimeout: any;

  constructor() {
    effect(() => {
      clearTimeout(this.completionTimeout);
      const isLoading = this.loadingService.loading();
      
      if (isLoading) {
        this.opacity.set(1);
        this.width.set(0);
        // Use timeout to ensure transition triggers
        setTimeout(() => this.width.set(70), 0);
      } else {
        // Only run completion animation if it was already loading
        if (this.width() > 0 && this.width() < 100) {
            this.width.set(100);
            // After width animation finishes, fade out
            this.completionTimeout = setTimeout(() => {
                this.opacity.set(0);
            }, 300); // should match transition-duration of width
        }
      }
    });
  }
}
