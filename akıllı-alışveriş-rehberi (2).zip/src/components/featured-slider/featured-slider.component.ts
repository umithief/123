

import { Component, ChangeDetectionStrategy, signal, OnInit, OnDestroy, input, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser, CommonModule, NgOptimizedImage } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Post } from '../../models/post.model';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';

@Component({
  selector: 'app-featured-slider',
  templateUrl: './featured-slider.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RouterLink, NgOptimizedImage, ImageOptimizerPipe],
  host: {
    '(window:scroll)': 'onWindowScroll()',
    '(touchstart)': 'onTouchStart($event)',
    '(touchend)': 'onTouchEnd($event)'
  }
})
export class FeaturedSliderComponent implements OnInit, OnDestroy {
  posts = input.required<Post[]>();
  
  currentIndex = signal(0);
  parallaxTransform = signal('scale(1.1)');
  
  private intervalId: ReturnType<typeof setInterval> | null = null;
  private platformId = inject(PLATFORM_ID);

  // Properties for swipe functionality
  private touchStartX = 0;
  private readonly swipeThreshold = 50; // Minimum pixels for a swipe

  ngOnInit(): void {
    this.startAutoPlay();
  }

  ngOnDestroy(): void {
    this.stopAutoPlay();
  }
  
  onWindowScroll(): void {
    if (isPlatformBrowser(this.platformId)) {
      const scrollY = window.scrollY;
      const speed = 0.4; // Parallax speed factor
      const scaleFactor = 0.0002; // How quickly it scales down

      // Calculate vertical translation for parallax effect
      const translateY = scrollY * speed;

      // Calculate scale, starting at 1.1 and decreasing. Cap at 1.0.
      let scale = 1.1 - scrollY * scaleFactor;
      if (scale < 1) {
        scale = 1;
      }
      
      this.parallaxTransform.set(`scale(${scale}) translateY(${translateY}px)`);
    }
  }

  startAutoPlay(): void {
    if (this.posts().length <= 1) return;
    this.stopAutoPlay(); // ensure no multiple intervals running
    this.intervalId = setInterval(() => {
      this.nextSlide();
    }, 5000); // Change slide every 5 seconds
  }

  stopAutoPlay(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  nextSlide(): void {
    this.currentIndex.update(current => (current + 1) % this.posts().length);
  }

  prevSlide(): void {
    this.currentIndex.update(current => (current - 1 + this.posts().length) % this.posts().length);
  }

  goToSlide(index: number): void {
    this.currentIndex.set(index);
    this.stopAutoPlay();
    this.startAutoPlay();
  }

  // --- Swipe Logic ---
  onTouchStart(event: TouchEvent): void {
    this.stopAutoPlay(); // Pause autoplay during user interaction
    this.touchStartX = event.changedTouches[0].clientX;
  }

  onTouchEnd(event: TouchEvent): void {
    const touchEndX = event.changedTouches[0].clientX;
    const deltaX = touchEndX - this.touchStartX;

    if (Math.abs(deltaX) > this.swipeThreshold) {
      if (deltaX < 0) {
        // Swiped left, same as next
        this.nextSlide();
      } else {
        // Swiped right, same as prev
        this.prevSlide();
      }
    }
    
    this.startAutoPlay(); // Resume autoplay after user interaction
  }
}
