import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-marquee',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="marquee-container">
      <div class="marquee-track">
        <div class="marquee-content">
          TEKNOLOJİ — TASARIM — YAZILIM — SEYAHAT —
        </div>
        <div class="marquee-content" aria-hidden="true">
          TEKNOLOJİ — TASARIM — YAZILIM — SEYAHAT —
        </div>
      </div>
    </div>
  `,
  styles: [`
    @keyframes scroll {
      from { transform: translateX(0); }
      to { transform: translateX(-50%); }
    }
    
    :host {
      display: block;
      width: 100%;
    }

    .marquee-container {
      width: 100%;
      overflow: hidden;
      padding: 1.5rem 0;
      border-top: 1px solid #e5e7eb;
      border-bottom: 1px solid #e5e7eb;
      white-space: nowrap;
    }
    .dark .marquee-container {
      border-color: #334155;
    }
    
    .marquee-track {
      display: flex;
      will-change: transform;
      animation: scroll 40s linear infinite;
    }

    .marquee-container:hover .marquee-track {
      animation-play-state: paused;
    }

    .marquee-content {
      flex-shrink: 0;
      font-size: 3rem; /* 48px */
      font-weight: 800;
      letter-spacing: 0.025em;
      text-transform: uppercase;
      color: transparent;
      -webkit-text-stroke: 1px var(--color-text-secondary);
      text-stroke: 1px var(--color-text-secondary);
      padding-right: 2rem; /* 32px */
    }
    
    @media (max-width: 768px) {
      .marquee-content {
        font-size: 2rem; /* 32px */
      }
      .marquee-track {
        animation-duration: 30s;
      }
    }
  `]
})
export class MarqueeComponent {}
