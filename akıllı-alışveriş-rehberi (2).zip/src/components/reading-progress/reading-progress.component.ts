import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-reading-progress',
  template: `
    <div class="h-1 bg-gradient-to-r from-purple-500 via-indigo-500 to-pink-500" [style.width.%]="progress()"></div>
  `,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(document:scroll)': 'onScroll()',
    'class': 'block w-full fixed top-0 left-0 z-30'
  }
})
export class ReadingProgressComponent {
  progress = signal<number>(0);

  onScroll(): void {
    const el = document.documentElement;
    const st = 'scrollTop';
    const sh = 'scrollHeight';
    const scrollPercent = (el[st] || document.body[st]) / ((el[sh] || document.body[sh]) - el.clientHeight) * 100;
    this.progress.set(scrollPercent);
  }
}