import { Component, ChangeDetectionStrategy, computed, inject, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { BlogService } from '../../services/blog.service';
import { CommentService } from '../../services/comment.service';
import { Post } from '../../models/post.model';
import { AuthService } from '../../services/auth.service';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';
import { AuthorReviewsComponent } from '../author-reviews/author-reviews.component';

@Component({
  selector: 'app-author-profile',
  templateUrl: './author-profile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, NgOptimizedImage, ImageOptimizerPipe, AuthorReviewsComponent],
})
export class AuthorProfileComponent {
  private blogService: BlogService = inject(BlogService);
  private authService: AuthService = inject(AuthService);
  private commentService: CommentService = inject(CommentService);
  private route: ActivatedRoute = inject(ActivatedRoute);
  private router: Router = inject(Router);

  private params = toSignal(this.route.paramMap);
  
  // State Signals
  activeTab = signal<'feed' | 'about'>('feed');
  isLiked = signal(false);
  isFollowing = signal(false);
  showSubscribeModal = signal(false);

  author = computed(() => {
    const name = this.params()?.get('name');
    if (!name) return null;
    return this.authService.getUserByName(name) ?? null;
  });

  posts = computed(() => {
    const name = this.author()?.name;
    if (!name) return [];
    return this.blogService.posts().filter(p => p.author === name);
  });
  
  authorStats = computed(() => {
    const authorPosts = this.posts();
    const allComments = this.commentService.allComments();
    
    const postIds = new Set(authorPosts.map(p => p.id));
    const totalComments = allComments.filter(c => postIds.has(c.postId)).length;
    
    const totalReadingTime = authorPosts.reduce((acc, post) => acc + this.blogService.calculateReadingTime(post.content), 0);
    const avgReadingTime = authorPosts.length > 0 ? Math.round(totalReadingTime / authorPosts.length) : 0;

    return {
      totalPosts: authorPosts.length,
      totalComments: totalComments,
      avgReadingTime: avgReadingTime
    };
  });
  
  authorTags = computed(() => {
    const allTags = this.posts().flatMap(p => p.tags);
    return [...new Set(allTags)];
  });

  goBack(): void {
    this.router.navigate(['/']);
  }

  selectPost(post: Post): void {
    this.router.navigate(['/blog', post.id]);
  }
  
  selectTab(tab: 'feed' | 'about'): void {
    this.activeTab.set(tab);
  }
  
  toggleLike(): void {
    this.isLiked.update(v => !v);
  }
  
  toggleFollow(): void {
    if (this.isFollowing()) {
      this.isFollowing.set(false);
    } else {
      this.showSubscribeModal.set(true);
    }
  }

  confirmSubscription(): void {
    this.isFollowing.set(true);
    this.showSubscribeModal.set(false);
  }
}
