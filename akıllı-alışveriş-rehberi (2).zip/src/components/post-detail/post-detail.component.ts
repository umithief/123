import { Component, ChangeDetectionStrategy, inject, SecurityContext, computed, signal, PLATFORM_ID, AfterViewInit, OnDestroy, Renderer2, ElementRef, effect } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonModule, isPlatformBrowser, DOCUMENT, NgOptimizedImage } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { BlogService } from '../../services/blog.service';
import { Post, HtmlBlock } from '../../models/post.model';
import { ReadingProgressComponent } from '../reading-progress/reading-progress.component';
import { CommentSectionComponent } from '../comment-section/comment-section.component';
import { AnimatedImageComponent } from '../animated-image/animated-image.component';
import { UiStateService } from '../../services/ui-state.service';
import { SoundService } from '../../services/sound.service';
import { SmartMosaicGalleryComponent } from '../smart-mosaic-gallery/smart-mosaic-gallery.component';
import { ArticleProgressIndicatorComponent } from '../article-progress-indicator/article-progress-indicator.component';
import { AuthService } from '../../services/auth.service';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';
import { SeoService } from '../../services/seo.service';
import { GlossaryPipe } from '../../pipes/glossary.pipe';
import { CitationCardComponent } from '../citation-card/citation-card.component';
import { PdfMagazineExportComponent } from '../../app/components/pdf-magazine-export/pdf-magazine-export.component';

@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReadingProgressComponent, CommentSectionComponent, AnimatedImageComponent, SmartMosaicGalleryComponent, ArticleProgressIndicatorComponent, NgOptimizedImage, ImageOptimizerPipe, GlossaryPipe, CitationCardComponent, PdfMagazineExportComponent],
  host: {
    '(window:scroll)': 'onWindowScroll()',
  }
})
export class PostDetailComponent implements AfterViewInit, OnDestroy {
  blogService: BlogService = inject(BlogService);
  private authService: AuthService = inject(AuthService);
  sanitizer: DomSanitizer = inject(DomSanitizer);
  private route: ActivatedRoute = inject(ActivatedRoute);
  private router: Router = inject(Router);
  private platformId: object = inject(PLATFORM_ID);
  private document: Document = inject(DOCUMENT);
  private uiStateService: UiStateService = inject(UiStateService);
  private soundService: SoundService = inject(SoundService);
  private elementRef: ElementRef = inject(ElementRef);
  private renderer: Renderer2 = inject(Renderer2);
  private seoService = inject(SeoService);
  
  private params = toSignal(this.route.paramMap);
  
  headerScrolled = signal<boolean>(false);
  isZenMode = this.uiStateService.isZenMode;

  // Signals for contextual share menu
  isShareTooltipVisible = signal(false);
  tooltipStyle = signal<{ top: string; left: string }>({ top: '0', left: '0' });
  selectedText = signal('');
  
  private unlistenMouseUp: (() => void) | null = null;
  private unlistenMouseDown: (() => void) | null = null;

  post = computed(() => {
    const id = this.params()?.get('id');
    if (!id) return null;
    return this.blogService.posts().find(p => p.id === +id) ?? null;
  });
  
  author = computed(() => {
    const email = this.post()?.userEmail;
    if (!email) return null;
    return this.authService.getUserByEmail(email) ?? null;
  });

  relatedPosts = computed(() => {
    const currentPost = this.post();
    if (!currentPost) {
        return [];
    }
    const allPosts = this.blogService.posts();
    const currentPostTags = new Set(currentPost.tags);

    return allPosts.filter(p => 
        p.id !== currentPost.id &&
        p.tags.some(tag => currentPostTags.has(tag))
    ).slice(0, 3);
  });
  
  constructor() {
    effect(() => {
      const currentPost = this.post();
      if (currentPost) {
        this.seoService.updateMetaTagsForPost(currentPost);
      }
    });
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.unlistenMouseUp = this.renderer.listen(this.document, 'mouseup', this.onMouseUp.bind(this));
      this.unlistenMouseDown = this.renderer.listen(this.document, 'mousedown', this.onMouseDown.bind(this));
    }
  }

  ngOnDestroy(): void {
    this.unlistenMouseUp?.();
    this.unlistenMouseDown?.();
    this.seoService.clearMetaTags();
  }

  private onMouseUp(event: MouseEvent): void {
    // Timeout to allow the browser to register the selection
    setTimeout(() => {
      const selection = this.document.getSelection();
      if (selection && !selection.isCollapsed && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        
        // Check if the selection is within our article content
        const articleContent = this.elementRef.nativeElement.querySelector('article');
        if (articleContent && articleContent.contains(range.commonAncestorContainer)) {
          const text = selection.toString().trim();
          
          if (text.length > 0) {
            this.selectedText.set(text);
            const rect = range.getBoundingClientRect();
            const top = rect.top - 45; // Position above selection
            const left = rect.left + rect.width / 2; // Center of selection
            
            this.tooltipStyle.set({
              top: `${top}px`,
              left: `${left}px`,
            });
            this.isShareTooltipVisible.set(true);
            return; // Exit here to not hide it
          }
        }
      }
      // If no valid selection or selection is outside article, hide the tooltip
      if (this.isShareTooltipVisible()) {
        this.isShareTooltipVisible.set(false);
      }
    }, 10);
  }

  private onMouseDown(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    // Hide if clicking outside the tooltip
    if (this.isShareTooltipVisible() && !target.closest('.share-tooltip')) {
      this.isShareTooltipVisible.set(false);
    }
  }

  shareSelectionOnTwitter(): void {
    const text = this.selectedText();
    if (!text) return;
    
    // Truncate text to fit Twitter's URL length constraints for the `text` parameter
    const maxLength = 280 - 23 - 25; // 280 limit - URL length - buffer & quotes
    const truncatedText = text.length > maxLength ? `"${text.substring(0, maxLength)}..."` : `"${text}"`;
    
    const url = this.getCurrentUrl();
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(truncatedText)}&url=${encodeURIComponent(url)}`;
    
    window.open(twitterUrl, '_blank', 'width=550,height=420');
    this.isShareTooltipVisible.set(false); // Hide after action
  }

  copySelectionToClipboard(): void {
    const text = this.selectedText();
    if (!text) return;
    
    navigator.clipboard.writeText(text).then(() => {
      console.log('Text copied to clipboard');
      this.isShareTooltipVisible.set(false);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
      this.isShareTooltipVisible.set(false);
    });
  }


  onWindowScroll(): void {
    const scrollY = window.scrollY;
    this.headerScrolled.set(scrollY > 50);
  }

  readingTime = computed(() => {
    const content = this.post()?.content;
    if (!content) {
      return 0;
    }
    return this.blogService.calculateReadingTime(content);
  });

  // Share URL computations
  private getCurrentUrl(): string {
    if (isPlatformBrowser(this.platformId)) {
      return this.document.location.href;
    }
    return '';
  }

  shareUrl = computed(() => this.getCurrentUrl());
  shareText = computed(() => `Bu harika rehbere göz atın: ${this.post()?.title}`);

  twitterShareUrl = computed(() => {
    const url = encodeURIComponent(this.shareUrl());
    const text = encodeURIComponent(this.shareText());
    return `https://twitter.com/intent/tweet?url=${url}&text=${text}`;
  });

  linkedinShareUrl = computed(() => {
    const url = encodeURIComponent(this.shareUrl());
    return `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
  });

  whatsappShareUrl = computed(() => {
    const url = encodeURIComponent(this.shareUrl());
    const text = encodeURIComponent(this.shareText());
    return `https://api.whatsapp.com/send?text=${text} ${url}`;
  });

  toggleZenMode(): void {
    this.uiStateService.toggleZenMode();
    this.soundService.playToggleSound();
  }

  viewAuthorProfile(authorName: string): void {
    this.router.navigate(['/author', authorName]);
  }

  goHome(): void {
    this.router.navigate(['/']);
  }

  selectRelatedPost(post: Post): void {
    this.router.navigate(['/blog', post.id]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}