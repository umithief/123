import { Component, ChangeDetectionStrategy, signal, OnInit, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';

@Component({
  selector: 'app-cookie-consent',
  standalone: true,
  imports: [CommonModule],
  templateUrl: '../../app/components/cookie-consent/cookie-consent.component.html',
  styleUrls: ['../../app/components/cookie-consent/cookie-consent.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CookieConsentComponent implements OnInit {
  private platformId = inject(PLATFORM_ID);
  isVisible = signal(false);

  private readonly COOKIE_CONSENT_KEY = 'cookie_consent';

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      const consentGiven = localStorage.getItem(this.COOKIE_CONSENT_KEY);
      if (!consentGiven) {
        setTimeout(() => {
          this.isVisible.set(true);
        }, 2000); // 2-second delay
      }
    }
  }

  acceptCookies(): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(this.COOKIE_CONSENT_KEY, 'true');
    }
    this.isVisible.set(false);
  }

  openSettings(): void {
    // Placeholder for settings functionality
    console.log('Cookie settings opened.');
  }
}