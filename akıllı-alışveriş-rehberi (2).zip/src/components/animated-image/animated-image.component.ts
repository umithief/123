import { Component, ChangeDetectionStrategy, input, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';

@Component({
  selector: 'app-animated-image',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage, ImageOptimizerPipe],
  templateUrl: './animated-image.component.html',
  styleUrls: ['./animated-image.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AnimatedImageComponent {
  src = input.required<string>();
  alt = input.required<string>();
  isLoaded = signal(false);

  onLoad(): void {
    this.isLoaded.set(true);
  }
}
