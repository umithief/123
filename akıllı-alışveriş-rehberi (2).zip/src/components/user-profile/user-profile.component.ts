import { Component, ChangeDetectionStrategy, inject, signal, OnInit, computed, effect } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { BlogService } from '../../services/blog.service';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Post } from '../../models/post.model';
import { User } from '../../models/user.model';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';
import { CommentService } from '../../services/comment.service';
import { ModalService } from '../../services/modal.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, NgOptimizedImage, ImageOptimizerPipe]
})
export class UserProfileComponent implements OnInit {
  private authService: AuthService = inject(AuthService);
  private blogService: BlogService = inject(BlogService);
  private commentService: CommentService = inject(CommentService);
  private router: Router = inject(Router);
  private fb: FormBuilder = inject(FormBuilder);
  private modalService: ModalService = inject(ModalService);

  currentUser = this.authService.currentUser;
  postsByCurrentUser = this.blogService.postsByCurrentUser;
  
  isEditing = signal(false);

  stats = computed(() => {
    const user = this.currentUser();
    if (!user) return { totalPosts: 0, totalComments: 0, totalLikes: 0 };
    
    const userPosts = this.postsByCurrentUser();
    const userPostIds = new Set(userPosts.map(p => p.id));
    
    const totalComments = this.commentService.allComments().filter(c => userPostIds.has(c.postId)).length;
    
    return {
      totalPosts: userPosts.length,
      totalComments: totalComments,
      totalLikes: user.totalLikes
    };
  });

  profileForm = this.fb.group({
    name: ['', Validators.required],
    username: [{value: '', disabled: true}],
    bio: [''],
    twitterUrl: ['', Validators.pattern('https?://(x|twitter)\\.com/.+')],
    linkedinUrl: ['', Validators.pattern('https?://(www\\.)?linkedin\\.com/.+')],
    githubUrl: ['', Validators.pattern('https?://github\\.com/.+')],
  });

  constructor() {
    effect(() => {
        this.updateForm(this.currentUser());
    });
  }

  ngOnInit(): void {
    this.updateForm(this.currentUser());
  }
  
  private updateForm(user: User | null): void {
     if (user) {
      this.profileForm.patchValue({
        name: user.name,
        username: user.username,
        bio: user.bio,
        twitterUrl: user.twitterUrl,
        linkedinUrl: user.linkedinUrl,
        githubUrl: user.githubUrl
      });
    }
  }

  toggleEdit(): void {
    this.isEditing.update(v => !v);
    if (!this.isEditing()) {
      this.updateForm(this.currentUser());
    }
  }

  saveProfile(): void {
    if (this.profileForm.valid) {
      const formValue = this.profileForm.value;
      this.authService.updateUser({ 
        name: formValue.name!, 
        bio: formValue.bio!,
        twitterUrl: formValue.twitterUrl!,
        linkedinUrl: formValue.linkedinUrl!,
        githubUrl: formValue.githubUrl!
      });
      this.isEditing.set(false);
    }
  }

  editPost(post: Post): void {
    this.blogService.openPostEditModal(post);
  }

  goHome(): void {
    this.router.navigate(['/']);
  }

  openBloggerApplicationModal(): void {
    this.modalService.openBloggerApplicationModal();
  }
}