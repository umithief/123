import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-newsletter-box',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './newsletter-box.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NewsletterBoxComponent {}
