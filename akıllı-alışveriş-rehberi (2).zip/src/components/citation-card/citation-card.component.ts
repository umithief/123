import { Component, ChangeDetectionStrategy, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResearchInfo } from '../../models/post.model';

@Component({
  selector: 'app-citation-card',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if(research()) {
      <div class="citation-card-wrapper">
        <!-- Stamp -->
        <div class="stamp">
          <div class="stamp-inner">
            <span class="stamp-line-1">ARAŞTIRILDI</span>
            <span class="stamp-line-2">{{ research().researchTimeInHours }} SAAT</span>
            <span class="stamp-line-3">DOĞRULANDI</span>
          </div>
        </div>

        <h3 class="font-serif text-xl font-bold text-gray-700 dark:text-gray-300 mb-4 border-b-2 border-gray-300 dark:border-gray-600 pb-2">
          Araştırma Notları & Kaynakça
        </h3>
        <ul class="space-y-3">
          @for(citation of research().citations; track $index) {
            <li class="flex items-start gap-3 text-sm">
              <i [class]="getIconClass(citation.type)" class="text-gray-500 dark:text-gray-400 mt-1 w-4 text-center"></i>
              <div class="flex-1">
                <p class="font-semibold text-gray-800 dark:text-gray-200">{{ citation.title }}</p>
                <div class="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
                  <span>{{ citation.authorOrSource }}</span>
                  @if(citation.url) {
                    <a [href]="citation.url" target="_blank" rel="noopener noreferrer" title="Kaynağa git" class="text-indigo-600 dark:text-indigo-400 hover:underline">
                      <i class="fas fa-external-link-alt"></i>
                    </a>
                  }
                </div>
              </div>
            </li>
          }
        </ul>
      </div>
    }
  `,
  styles: [`
    .citation-card-wrapper {
      position: relative;
      background-color: #FFFBEB;
      border: 1px solid #FDE68A; /* yellow-300 */
      border-radius: 0.5rem; /* rounded-lg */
      padding: 1.5rem; /* p-6 */
      margin-top: 3rem; /* my-12 */
      margin-bottom: 3rem;
      box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
      /* Old paper texture */
      background-image: url('data:image/svg+xml,%3Csvg width="6" height="6" viewBox="0 0 6 6" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="%23d4cba7" fill-opacity="0.1" fill-rule="evenodd"%3E%3Cpath d="M5 0h1L0 6V5zM6 5v1H5z"/%3E%3C/g%3E%3C/svg%3E');
    }

    .dark .citation-card-wrapper {
      background-color: rgba(67, 56, 20, 0.1); /* Equivalent to dark:bg-yellow-900/20 */
      border-color: rgba(82, 63, 2, 0.5); /* Equivalent to dark:border-yellow-800/50 */
    }

    .stamp {
      position: absolute;
      top: 1rem; /* top-4 */
      right: 1rem; /* right-4 */
      width: 6rem; /* w-24 */
      height: 6rem; /* h-24 */
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0.8;
    }
    
    .stamp-inner {
      width: 100%;
      height: 100%;
      border: 4px solid rgba(185, 28, 28, 0.8); /* border-red-700/80 */
      border-radius: 9999px; /* rounded-full */
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: rgba(185, 28, 28, 0.9); /* text-red-700/90 */
      transform: rotate(12deg);
      font-family: 'Courier New', Courier, monospace;
      text-transform: uppercase;
    }
    
    .dark .stamp-inner {
      border-color: rgba(248, 113, 113, 0.8); /* dark:border-red-500/80 */
      color: rgba(248, 113, 113, 0.9); /* dark:text-red-500/90 */
    }

    .stamp-line-1, .stamp-line-3 {
      font-size: 10px;
      font-weight: 700; /* font-bold */
      letter-spacing: 0.05em; /* tracking-wider */
    }
    .stamp-line-2 {
      font-size: 0.875rem; /* text-sm */
      font-weight: 800; /* font-extrabold */
      margin: 0.125rem 0; /* my-0.5 */
      border-top: 2px solid rgba(185, 28, 28, 0.8); /* border-y-2 border-red-700/80 */
      border-bottom: 2px solid rgba(185, 28, 28, 0.8);
      width: 100%;
    }
    
    .dark .stamp-line-2 {
       border-color: rgba(248, 113, 113, 0.8);
    }

    /* Responsive stamp */
    @media (max-width: 640px) {
      .stamp {
        width: 5rem; /* w-20 */
        height: 5rem; /* h-20 */
        top: 0.5rem; /* top-2 */
        right: 0.5rem; /* right-2 */
      }
      .stamp-line-1, .stamp-line-3 {
        font-size: 8px;
      }
      .stamp-line-2 {
        font-size: 0.75rem; /* text-xs */
      }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CitationCardComponent {
  research = input.required<ResearchInfo>();

  getIconClass(type: 'book' | 'article' | 'video'): string {
    switch (type) {
      case 'book': return 'fas fa-book';
      case 'article': return 'fas fa-newspaper';
      case 'video': return 'fab fa-youtube';
      default: return 'fas fa-link';
    }
  }
}
