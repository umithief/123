import { Component, ChangeDetectionStrategy, output, inject, ViewChild, ElementRef, AfterViewInit, Renderer2 } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators, FormArray, FormGroup } from '@angular/forms';
import { PostCreatePayload, ResearchInfo, Citation } from '../../models/post.model';
import { BlogService } from '../../services/blog.service';

@Component({
  selector: 'app-post-create-modal',
  standalone: true,
  templateUrl: './post-create-modal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule]
})
export class PostCreateModalComponent implements AfterViewInit {
  private fb: FormBuilder = inject(FormBuilder);
  private blogService: BlogService = inject(BlogService);
  private renderer: Renderer2 = inject(Renderer2);
  
  closeModal = output<void>();
  savePost = output<PostCreatePayload>();

  allCategories = this.blogService.allCategories;
  
  @ViewChild('contentEditor') contentEditor!: ElementRef<HTMLDivElement>;

  createForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    summary: ['', [Validators.required, Validators.maxLength(250)]],
    imageUrl: ['', [Validators.required, Validators.pattern('https?://.+')]],
    category: ['', Validators.required],
    content: ['', Validators.required],
    research: this.fb.group({
      researchTimeInHours: [0, [Validators.min(0)]],
      citations: this.fb.array([])
    })
  });
  
  get citations(): FormArray {
    return this.createForm.get('research.citations') as FormArray;
  }

  createCitationGroup(): FormGroup {
    return this.fb.group({
      type: ['article' as Citation['type'], Validators.required],
      title: ['', Validators.required],
      authorOrSource: ['', Validators.required],
      url: ['', Validators.pattern('https?://.+')]
    });
  }

  addCitation(): void {
    this.citations.push(this.createCitationGroup());
  }

  removeCitation(index: number): void {
    this.citations.removeAt(index);
  }

  ngAfterViewInit(): void {
    // You can set initial content if needed, for example a placeholder
    // this.renderer.setProperty(this.contentEditor.nativeElement, 'innerHTML', '<p>Buraya yazmaya başlayın...</p>');
  }

  onContentChange(): void {
    if (this.contentEditor) {
      const content = this.contentEditor.nativeElement.innerHTML;
      this.createForm.controls.content.setValue(content);
      this.createForm.controls.content.markAsTouched();
    }
  }
  
  formatDoc(command: string, value: string | null = null): void {
    document.execCommand(command, false, value);
    this.contentEditor.nativeElement.focus();
    this.onContentChange(); // Update form value after formatting
  }
  
  createLink(): void {
    const url = prompt('Link URL\'sini girin:');
    if (url) {
      this.formatDoc('createLink', url);
    }
  }

  onClose(): void {
    this.closeModal.emit();
  }

  onSubmit(): void {
    this.createForm.markAllAsTouched();
    if (this.createForm.valid) {
      const formValue = this.createForm.getRawValue();

      let researchData: ResearchInfo | undefined = undefined;
      if (formValue.research && (formValue.research.researchTimeInHours > 0 || formValue.research.citations.length > 0)) {
         const validCitations = formValue.research.citations.filter((c: any) => c.title && c.authorOrSource);
         if(validCitations.length > 0 || formValue.research.researchTimeInHours > 0) {
            researchData = {
              researchTimeInHours: formValue.research.researchTimeInHours || 0,
              citations: validCitations
            };
         }
      }

      const newPostData: PostCreatePayload = {
        title: formValue.title!,
        summary: formValue.summary!,
        imageUrl: formValue.imageUrl!,
        tags: [formValue.category!],
        content: formValue.content!,
        research: researchData
      };
      this.savePost.emit(newPostData);
    }
  }
}