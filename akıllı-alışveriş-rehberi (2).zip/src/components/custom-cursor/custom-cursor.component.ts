import { Component, ChangeDetectionStrategy, signal, inject, PLATFORM_ID, OnInit, OnDestroy, Renderer2 } from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';

@Component({
  selector: 'app-custom-cursor',
  templateUrl: './custom-cursor.component.html',
  styleUrls: ['./custom-cursor.component.css'],
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule]
})
export class CustomCursorComponent implements OnInit, OnDestroy {
  private platformId = inject(PLATFORM_ID);
  private renderer = inject(Renderer2);

  // Signals for cursor state
  ringX = signal(0);
  ringY = signal(0);
  isHovering = signal(false);
  isVisible = signal(false);

  // Target positions for smooth animation
  private targetX = 0;
  private targetY = 0;

  private unlistenMouseMove: (() => void) | null = null;
  private unlistenMouseEnter: (() => void) | null = null;
  private unlistenMouseLeave: (() => void) | null = null;
  private unlistenMouseOver: (() => void) | null = null;
  private unlistenMouseOut: (() => void) | null = null;
  
  private animationFrameId: number | null = null;
  
  // Only enable on non-touch devices
  isDesktop = isPlatformBrowser(this.platformId) && window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  ngOnInit(): void {
    if (this.isDesktop) {
      this.unlistenMouseMove = this.renderer.listen('document', 'mousemove', this.onMouseMove.bind(this));
      this.unlistenMouseEnter = this.renderer.listen('document', 'mouseenter', () => this.isVisible.set(true));
      this.unlistenMouseLeave = this.renderer.listen('document', 'mouseleave', () => this.isVisible.set(false));
      
      // Use event delegation for hover detection
      this.unlistenMouseOver = this.renderer.listen(document, 'mouseover', (event: MouseEvent) => {
        const target = event.target as HTMLElement;
        if (target.closest('a, button, [routerLink], [role="button"], .post-card, .cursor-pointer')) {
          this.isHovering.set(true);
        }
      });
      
      this.unlistenMouseOut = this.renderer.listen(document, 'mouseout', (event: MouseEvent) => {
        const target = event.target as HTMLElement;
        const relatedTarget = event.relatedTarget as HTMLElement | null;
        const closestInteractive = target.closest('a, button, [routerLink], [role="button"], .post-card, .cursor-pointer');
        
        // Ensure mouseout is not just moving to a child element
        if (closestInteractive && (!relatedTarget || !closestInteractive.contains(relatedTarget))) {
           this.isHovering.set(false);
        }
      });
      
      this.animateCursor();
    }
  }

  onMouseMove(event: MouseEvent): void {
    this.targetX = event.clientX;
    this.targetY = event.clientY;

    if (!this.isVisible()) {
      this.isVisible.set(true);
      // Initialize ring position to avoid jump on first move
      this.ringX.set(this.targetX);
      this.ringY.set(this.targetY);
    }
  }
  
  animateCursor(): void {
    // Linear interpolation for smooth movement
    const lerp = (start: number, end: number, amt: number) => (1 - amt) * start + amt * end;
    
    let currentRingX = this.ringX();
    let currentRingY = this.ringY();

    currentRingX = lerp(currentRingX, this.targetX, 0.2);
    currentRingY = lerp(currentRingY, this.targetY, 0.2);
    
    this.ringX.set(currentRingX);
    this.ringY.set(currentRingY);
    
    this.animationFrameId = requestAnimationFrame(this.animateCursor.bind(this));
  }

  ngOnDestroy(): void {
    this.unlistenMouseMove?.();
    this.unlistenMouseEnter?.();
    this.unlistenMouseLeave?.();
    this.unlistenMouseOver?.();
    this.unlistenMouseOut?.();
    
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }
}