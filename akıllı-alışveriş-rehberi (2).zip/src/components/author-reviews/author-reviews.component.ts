import { Component, ChangeDetectionStrategy, computed, inject, input } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { CommentService } from '../../services/comment.service';
import { BlogService } from '../../services/blog.service';
import { AuthService } from '../../services/auth.service';
import { Comment } from '../../models/comment.model';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';
import { TimeAgoPipe } from '../../pipes/time-ago.pipe';

interface Review extends Comment {
  rating: number;
}

@Component({
  selector: 'app-author-reviews',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage, ImageOptimizerPipe, TimeAgoPipe],
  templateUrl: './author-reviews.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AuthorReviewsComponent {
  authorEmail = input.required<string>();

  private blogService = inject(BlogService);
  private commentService = inject(CommentService);
  private authService = inject(AuthService);

  reviews = computed<Review[]>(() => {
    const authorEmail = this.authorEmail();
    const allPosts = this.blogService.posts();
    const allComments = this.commentService.allComments();

    const authorPostIds = new Set(
      allPosts.filter(p => p.userEmail === authorEmail).map(p => p.id)
    );

    return allComments
      .filter(comment => authorPostIds.has(comment.postId))
      .map(comment => ({
        ...comment,
        // Generate a deterministic "random" rating for visual purposes
        rating: (comment.content.length % 3) + 3, // Returns 3, 4, or 5
      }))
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  });
  
  overallStats = computed(() => {
    const currentReviews = this.reviews();
    if (currentReviews.length === 0) {
      return { average: 0, total: 0, distribution: [0, 0, 0, 0, 0] };
    }
    
    const totalRating = currentReviews.reduce((acc, r) => acc + r.rating, 0);
    const average = totalRating / currentReviews.length;
    
    const distribution = [0, 0, 0, 0, 0];
    currentReviews.forEach(r => {
      distribution[5 - r.rating]++;
    });
    
    return {
      average: parseFloat(average.toFixed(1)),
      total: currentReviews.length,
      distribution: distribution.map(d => (d / currentReviews.length) * 100)
    };
  });
  
  getCommenter(email: string) {
    return this.authService.getUserByEmail(email);
  }
}
