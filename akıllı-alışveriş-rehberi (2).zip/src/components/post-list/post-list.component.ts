import { Component, ChangeDetectionStrategy, inject, input } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Post } from '../../models/post.model';
import { AuthService } from '../../services/auth.service';
import { ImageOptimizerPipe } from '../../app/pipes/image-optimizer.pipe';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RouterLink, NgOptimizedImage, ImageOptimizerPipe]
})
export class PostListComponent {
  posts = input.required<Post[]>();
  loading = input<boolean>(false);
  private authService = inject(AuthService);

  getAuthorAvatar(email: string): string | undefined {
    return this.authService.getUserByEmail(email)?.avatarUrl;
  }
}
