import { Post } from '../models/post.model';

export const POSTS: Post[] = [
  {
    id: 1,
    title: "Yapay Zeka Asistanlarının Yükselişi: 2024'ün En İyileri",
    summary: "Yapay zeka asistanları, günlük hayatımızı ve iş akışlarımızı kökten değiştiriyor. Bu yazıda, 2024 yılının en popüler ve yetenekli yapay zeka asistanlarını inceliyoruz.",
    author: 'Elif Kara',
    userEmail: 'elif.kara@example.com',
    publicationDate: '2024-08-10',
    tags: ['Teknoloji', 'Yapay Zeka', 'Verimlilik'],
    imageUrl: 'https://picsum.photos/seed/ai-tech/800/400',
    content: [
      {
        type: 'html',
        content: `
          <p class="mb-4">Yapay zeka asistanları, günlük hayatımızı ve iş akışlarımızı kökten değiştiriyor. Bu yazıda, 2024 yılının en popüler ve yetenekli yapay zeka asistanlarını inceliyor, hangisinin ihtiyaçlarınıza en uygun olduğunu keşfetmenize yardımcı oluyoruz.</p>
          <img src="https://picsum.photos/seed/ai-assistant-inside/800/450" alt="AI Assistants Comparison" class="my-6 rounded-lg shadow-md" loading="lazy">
          <p class="mb-4">Sadece komutları yerine getiren basit programlardan, karmaşık problemleri çözebilen ve yaratıcı içerikler üretebilen gelişmiş platformlara evrildiler. Bu dönüşüm, verimliliğimizi artırma ve yaratıcılığımızı tetikleme konusunda inanılmaz fırsatlar sunuyor.</p>
          <h3 class="text-xl font-semibold mt-6 mb-2">Öne Çıkan Asistanlar</h3>
          <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
            <li><strong>OpenAI ChatGPT-4o:</strong> Metin, ses ve görüntü girdilerini anlama ve işleme yeteneğiyle çok yönlü bir güç merkezi.</li>
            <li><strong>Google Gemini:</strong> Google ekosistemiyle derin entrasyonu sayesinde kişiselleştirilmiş ve bağlamsal yardım sunuyor.</li>
            <li><strong>Claude 3 Opus:</strong> Özellikle uzun metin analizi, özetleme ve karmaşık akıl yürütme konularında öne çıkıyor.</li>
            <li><strong>Microsoft Copilot:</strong> Windows ve Office uygulamalarıyla bütünleşik çalışarak iş ve ofis verimliliğini en üst düzeye çıkarıyor.</li>
          </ul>
          <div class="callout callout-info">
              <div class="callout-icon">ℹ️</div>
              <div class="callout-content"><p>Bu asistanların çoğu, temel özelliklerini ücretsiz olarak sunarken, daha gelişmiş yetenekler için abonelik tabanlı "Pro" veya "Premium" planlar sunmaktadır. İhtiyaçlarınıza en uygun olanı belirlemek için bu planların özelliklerini karşılaştırmayı unutmayın.</p></div>
          </div>
          <blockquote class="my-6">
            <p>En iyi yapay zeka asistanları sadece birer araç değil; kendi zekamızı ve yaratıcılığımızı artıran birer işbirlikçidir.</p>
          </blockquote>
          <p>Seçim yaparken, hangi asistanın günlük iş akışlarınıza en iyi entegre olacağını ve hangi özelliklerin sizin için en önemli olduğunu düşünmelisiniz. Ücretsiz deneme sürümlerinden faydalanarak farklı platformları test etmek, en doğru kararı vermenize yardımcı olacaktır.</p>
        `,
      }
    ],
    research: {
      researchTimeInHours: 18,
      citations: [
        {
          type: 'article',
          title: 'Official GPT-4o Announcement',
          authorOrSource: 'OpenAI Blog',
          url: 'https://openai.com/index/hello-gpt-4o/'
        },
        {
          type: 'article',
          title: 'Google I/O 2024: Everything Gemini',
          authorOrSource: 'Google Blog',
          url: 'https://blog.google/technology/ai/google-io-2024-gemini-era/'
        },
        {
          type: 'video',
          title: 'Microsoft Copilot Keynote',
          authorOrSource: 'Microsoft Ignite',
          url: 'https://www.youtube.com/watch?v=s_eI-p2_9w0'
        }
      ]
    }
  },
  {
    id: 2,
    title: 'Dijital Minimalizm: Teknolojiyle Daha Anlamlı Bir İlişki Kurmak',
    summary: "Sürekli bildirimler ve dijital dağınıklık modern hayatın bir parçası. Dijital minimalizm, bu kaostan kurtulmanın ve teknolojiyle daha bilinçli, anlamlı bir ilişki kurmanın anahtarını sunuyor.",
    author: 'Barış Cengiz',
    userEmail: 'baris.cengiz@example.com',
    publicationDate: '2024-08-08',
    tags: ['Minimalizm', 'Teknoloji', 'Yaşam Tarzı'],
    imageUrl: 'https://picsum.photos/seed/minimalism/800/400',
    content: [
      {
        type: 'html',
        content: `
          <p class="mb-4">Sürekli bildirimler, sonsuz akışlar ve dijital dağınıklık... Modern teknoloji hayatımızı kolaylaştırsa da, dikkatimizi dağıtarak ve zihinsel yorgunluğa neden olarak bizi tüketebilir. Dijital minimalizm, bu kaostan kurtulmanın ve teknolojiyle daha bilinçli bir ilişki kurmanın anahtarıdır.</p>
          <p class="mb-4">Bu felsefe, teknolojiyi tamamen reddetmek yerine, onu değerlerinizle ve hedeflerinizle uyumlu bir şekilde kullanmaya odaklanır. Amaç, daha az ama daha iyi teknoloji kullanarak zihinsel alan kazanmak ve gerçekten önemli olan şeylere odaklanmaktır.</p>
          <h3 class="text-xl font-semibold mt-6 mb-2">Dijital Minimalizm İçin Pratik Adımlar</h3>
          <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
            <li><strong>Bildirimleri Kapatın:</strong> Acil olmayan tüm uygulama bildirimlerini kapatarak dikkatinizin kontrolünü geri alın.</li>
            <li><strong>Uygulama Temizliği:</strong> Telefonunuzdaki uygulamaları gözden geçirin. Son bir ayda kullanmadığınız veya size değer katmayan uygulamaları silin.</li>
            <li><strong>Sosyal Medya Detoksu:</strong> Belirli zamanlarda (örneğin, hafta sonları) sosyal medyadan uzak durarak zihninizi dinlendirin.</li>
            <li><strong>Tek Amaca Yönelik Cihazlar:</strong> Mümkünse, her iş için farklı cihazlar kullanın. Örneğin, okumak için e-kitap okuyucu, yazmak için sadece bir metin düzenleyici.</li>
          </ul>
        `,
      },
      {
        type: 'html',
        content: `
          <div class="callout callout-warning">
            <div class="callout-icon">⚠️</div>
            <div class="callout-content"><p><strong>Uyarı:</strong> Dijital detoks sırasında "kaçırma korkusu" (FOMO) yaşayabilirsiniz. Bu normal bir tepkidir. Bu hissin geçici olduğunu ve uzun vadede daha odaklanmış bir zihne sahip olacağınızı kendinize hatırlatın.</p></div>
          </div>
          <p>Dijital minimalizm, bir gecede olacak bir şey değildir; bu bir süreçtir. Küçük adımlarla başlayarak, teknolojinin hayatınızdaki rolünü yeniden şekillendirebilir ve daha odaklanmış, huzurlu bir yaşam sürebilirsiniz.</p>
        `,
      }
    ],
  },
  {
    id: 3,
    title: 'Sırt Çantasıyla Güneydoğu Asya: Düşük Bütçeyle Unutulmaz Bir Macera',
    summary: "Güneydoğu Asya, sırt çantalı gezginler için bir cennettir. Zengin kültürü, nefes kesen doğası ve misafirperver insanlarıyla dolu bu coğrafyayı düşük bir bütçeyle nasıl keşfedebileceğinizi anlatıyoruz.",
    author: 'Selin Gezgin',
    userEmail: 'selin.gezgin@example.com',
    publicationDate: '2024-08-05',
    tags: ['Seyahat', 'Macera', 'Bütçe'],
    imageUrl: 'https://picsum.photos/seed/travel-asia/800/400',
    content: [
      {
        type: 'html',
        content: `
          <p class="mb-4">Güneydoğu Asya, zengin kültürü, nefes kesen doğası ve misafirperver insanlarıyla sırt çantalı gezginler için bir cennettir. Üstelik, doğru planlama ile bu eşsiz coğrafyayı şaşırtıcı derecede düşük bir bütçeyle keşfetmek mümkün.</p>
          <p class="mb-4">Tayland'ın hareketli sokaklarından Vietnam'ın sakin pirinç tarlalarına, Kamboçya'nın antik tapınaklarından Endonezya'nın volkanik adalarına kadar uzanan bu macera, size hayat boyu unutamayacağınız anılar vaat ediyor. İşte bu yolculuğa çıkmadan önce bilmeniz gerekenler.</p>
        `,
      },
      {
        type: 'gallery',
        images: [
          'https://picsum.photos/seed/gallery-1/800/600',
          'https://picsum.photos/seed/gallery-2/800/600',
          'https://picsum.photos/seed/gallery-3/800/600',
          'https://picsum.photos/seed/gallery-4/800/600'
        ]
      },
      {
        type: 'html',
        content: `
          <h3 class="text-xl font-semibold mt-6 mb-2">Bütçe Dostu Seyahat İpuçları</h3>
          <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
            <li><strong>Hostellerde Konaklayın:</strong> Sosyalleşmek ve konaklama maliyetini düşürmek için hosteller harika bir seçenektir.</li>
            <li><strong>Sokak Yemeklerini Deneyin:</strong> Lezzetli ve otantik yerel yemekleri en uygun fiyata tatmak için sokak tezgahlarını tercih edin.</li>
            <li><strong>Yerel Ulaşımı Kullanın:</strong> Turistik otobüsler yerine yerel halkın kullandığı otobüsleri ve trenleri kullanarak hem tasarruf edin hem de kültürü daha yakından tanıyın.</li>
            <li><strong>Pazarlık Yapın:</strong> Özellikle pazarlarda ve taksilerde pazarlık yapmak, bölge kültürünün bir parçasıdır ve bütçenize katkı sağlar.</li>
          </ul>
          <p>Esnek bir planla yola çıkın ve kendinizi akışa bırakın. Güneydoğu Asya'nın büyüsü, genellikle plansız anlarda ve beklenmedik keşiflerde saklıdır. Cesur olun, yeni şeyler deneyin ve bu inanılmaz maceranın tadını çıkarın!</p>
        `,
      }
    ],
  },
  {
    id: 4,
    title: 'Yazılıma Nereden Başlamalı? İlk Programlama Dilini Seçme Rehberi',
    summary: "Yazılım dünyasına ilk adımı atmak göz korkutucu olabilir. Bu rehber, hedeflerinize (web, mobil, veri bilimi) göre hangi programlama dilini seçmeniz gerektiği konusunda size yol gösterecek.",
    author: 'Ahmet Kodlar',
    userEmail: 'ahmet.kodlar@example.com',
    publicationDate: '2024-08-02',
    tags: ['Yazılım', 'Programlama', 'Kariyer'],
    imageUrl: 'https://picsum.photos/seed/software-code/800/400',
    content: [
      {
        type: 'html',
        content: `
          <p class="mb-4">Yazılım dünyasına adım atmak heyecan verici bir yolculuktur, ancak ilk adımı atmak, yani hangi programlama dilini öğreneceğine karar vermek, göz korkutucu olabilir. Bu rehber, hedeflerinize göre en doğru dili seçmenize yardımcı olmak için tasarlandı.</p>
          <p class="mb-4">"En iyi" programlama dili diye bir şey yoktur; sadece belirli bir iş için "daha uygun" diller vardır. Web geliştirme mi, mobil uygulama mı, veri bilimi mi yoksa oyun geliştirme mi yapmak istediğiniz, seçeceğiniz dili doğrudan etkileyecektir.</p>
          <h3 class="text-xl font-semibold mt-6 mb-2">Hedeflerinize Göre Dil Seçimi</h3>
          <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
            <li><strong>Web Geliştirme (Frontend):</strong> HTML, CSS ve <strong>JavaScript</strong> ile başlamalısınız. JavaScript, web'in temel taşıdır ve modern framework'ler (React, Angular, Vue) için bir ön koşuldur.</li>
            <li><strong>Web Geliştirme (Backend):</strong> <strong>Python</strong> (Django, Flask) ve <strong>JavaScript</strong> (Node.js) yeni başlayanlar için popüler ve güçlü seçeneklerdir. Java ve C# ise kurumsal düzeyde yaygındır.</li>
            <li><strong>Mobil Geliştirme:</strong> iOS için <strong>Swift</strong>, Android için <strong>Kotlin</strong> modern ve tercih edilen dillerdir. React Native veya Flutter gibi platformlar ise tek kod tabanıyla her iki platforma da uygulama geliştirmenizi sağlar.</li>
            <li><strong>Veri Bilimi ve Yapay Zeka:</strong> <strong>Python</strong>, zengin kütüphanele ri (Pandas, NumPy, TensorFlow) sayesinde bu alanda tartışmasız liderdir.</li>
          </ul>
          <div class="callout callout-tip">
              <div class="callout-icon">💡</div>
              <div class="callout-content"><p><strong>İpucu:</strong> Teoride boğulmayın! Bir dil seçtikten sonra, öğrenme sürecinizi hızlandırmak için basit bir proje (örneğin bir yapılacaklar listesi uygulaması veya basit bir blog) yapmaya başlayın. Pratik, en iyi öğretmendir.</p></div>
          </div>
          <p>Unutmayın, bir dili öğrendikten sonra diğerlerini öğrenmek çok daha kolaylaşır. Önemli olan, temel programlama mantığını ve problem çözme becerilerini kavramaktır. Bir dil seçin, bir proje hedefi belirleyin ve kodlamaya başlayın!</p>
        `,
      }
    ],
    research: {
      researchTimeInHours: 12,
      citations: [
        {
          type: 'book',
          title: 'Clean Code: A Handbook of Agile Software Craftsmanship',
          authorOrSource: 'Robert C. Martin',
          isbn: '9780132350884'
        },
        {
          type: 'article',
          title: 'MDN Web Docs: JavaScript',
          authorOrSource: 'Mozilla',
          url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript'
        },
        {
          type: 'article',
          title: '2023 Developer Survey',
          authorOrSource: 'Stack Overflow',
          url: 'https://survey.stackoverflow.co/2023/'
        }
      ]
    }
  },
  {
    id: 5,
    title: 'Modern Gezginin Çantasındaki Olmazsa Olmaz Teknolojik Araçlar',
    summary: "Modern seyahat deneyimi teknolojiyle şekilleniyor. Güvenli, kolay ve zengin bir macera için 21. yüzyıl gezgininin sırt çantasında olması gereken teknolojik araçları listeledik.",
    author: 'Selin Gezgin',
    userEmail: 'selin.gezgin@example.com',
    publicationDate: '2024-07-29',
    tags: ['Teknoloji', 'Seyahat', 'Ekipman'],
    imageUrl: 'https://picsum.photos/seed/tech-travel/800/400',
    content: [
      {
        type: 'html',
        content: `
          <p class="mb-4">Seyahat etmek artık sadece bir harita ve pusuladan ibaret değil. Teknoloji, seyahat deneyimlerimizi daha güvenli, daha kolay ve daha zengin hale getiriyor. Peki, 21. yüzyıl gezgininin sırt çantasında neler olmalı?</p>
          <p class="mb-4">Doğru teknolojik araçlar, dil bariyerlerini aşmaktan en iyi yerel restoranı bulmaya, anılarınızı ölümsüzleştirmekten acil durumlarda güvende kalmaya kadar her konuda size yardımcı olabilir. İşte benim favori seyahat teknolojilerim.</p>
          <h3 class="text-xl font-semibold mt-6 mb-2">Gezginin Teknoloji Kiti</h3>
          <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
            <li><strong>Taşınabilir Şarj Cihazı (Power Bank):</strong> Uzun uçuşlarda veya şarj imkanı olmayan yerlerde hayat kurtarır. En az 10.000 mAh kapasiteli bir model tercih edin.</li>
            <li><strong>Evrensel Priz Adaptörü:</strong> Farklı ülkelerdeki farklı priz tipleri için tek bir çözüm sunar. USB portlu olanlar ekstra pratiklik sağlar.</li>
            <li><strong>Gürültü Engelleyici Kulaklık:</strong> Uçak, tren veya gürültülü hostel odalarında huzur bulmanızı sağlar.</li>
            <li><strong>eSIM veya Yerel SIM Kart:</strong> Yüksek dolaşım ücretlerinden kaçınmak için internet erişimi hayati önem taşır. eSIM, fiziksel kart değiştirmeden plan satın alma kolaylığı sunar.</li>
            <li><strong>Kompakt bir Kamera veya İyi Kameralı Telefon:</strong> Anılarınızı yüksek kalitede kaydetmek için yatırım yapmaya değer.</li>
          </ul>
          <p>Teknolojiyi bir amaç olarak değil, seyahat deneyiminizi zenginleştirecek bir araç olarak görün. Hafif ve çok fonksiyonlu ürünler seçerek çantanızı gereksiz yere ağırlaştırmaktan kaçının.</p>
        `,
      }
    ],
  },
  {
    id: 6,
    title: 'Temiz Kod Sanatı: Yazılımda Minimalist Yaklaşım',
    summary: "Minimalizm sadece eşyalarla ilgili değildir; aynı zamanda yazılım geliştirmenin de temelidir. Temiz kod yazmanın prensiplerini ve projelerin sürdürülebilirliği için neden hayati olduğunu keşfedin.",
    author: 'Ahmet Kodlar',
    userEmail: 'ahmet.kodlar@example.com',
    publicationDate: '2024-07-25',
    tags: ['Yazılım', 'Minimalizm', 'Kod Kalitesi'],
    imageUrl: 'https://picsum.photos/seed/clean-code/800/400',
    content: [
      {
        type: 'html',
        content: `
          <p class="mb-4">Minimalizm sadece eşyalarla ilgili bir felsefe değildir; aynı zamanda yazılım geliştirmenin de temel taşlarından biridir. "Temiz Kod", okunması, anlaşılması ve bakımı kolay olan, gereksiz karmaşıklıktan arındırılmış koddur. Bu minimalist yaklaşım, uzun vadede projelerin sürdürülebilirliği için hayati önem taşır.</p>
          <p class="mb-4">Karmaşık ve "akıllıca" görünen kodlar yazmak yerine, amacını en basit ve en açık şekilde ifade eden kodlar yazmayı hedeflemek, hem kendiniz hem de ekibiniz için yapacağınız en büyük iyiliktir. Kod, yazıldığı zamandan çok daha fazla okunur.</p>
          <h3 class="text-xl font-semibold mt-6 mb-2">Temiz Kod İlkeleri</h3>
          <ul class="list-disc list-inside mb-4 pl-4 space-y-2">
            <li><strong>Anlamlı İsimlendirme:</strong> Değişken, fonksiyon ve sınıf isimleri ne işe yaradıklarını açıkça belirtmelidir. Kısaltmalardan ve belirsiz isimlerden kaçının.</li>
            <li><strong>Tek Sorumluluk Prensibi (SRP):</strong> Her fonksiyon veya sınıf, sadece tek bir iş yapmalı ve o işi iyi yapmalıdır.</li>
            <li><strong>Kendini Tekrar Etme (DRY - Don't Repeat Yourself):</strong> Kod tekrarından kaçının. Tekrar eden mantığı yeniden kullanılabilir fonksiyonlara veya sınıflara ayırın.</li>
            <li><strong>Kısa ve Odaklanmış Fonksiyonlar:</strong> Fonksiyonlar mümkün olduğunca kısa olmalı ve bir ekranı geçmemelidir. Bu, anlaşılırlığı ve test edilebilirliği artırır.</li>
            <li><strong>Yorumlar Neden'i Açıklamalı, Ne'yi Değil:</strong> Kodunuz ne yaptığını zaten anlatmalıdır. Yorumlar, kodun neden o şekilde yazıldığına dair karmaşık veya sıra dışı kararları açıklamak için kullanılmalıdır.</li>
          </ul>
          <p>Temiz kod yazmak, zamanla geliştirilen bir beceri ve bir disiplindir. Kodunuzu yazarken sürekli olarak "Bunu daha basit nasıl yapabilirim?" diye sormak, sizi daha iyi bir yazılımcı yapacak en önemli alışkanlıklardan biridir.</p>
        `,
      }
    ],
  },
];