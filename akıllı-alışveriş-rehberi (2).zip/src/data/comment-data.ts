import { Comment } from '../models/comment.model';

export const COMMENTS: Comment[] = [
  // Comments for Post 1
  {
    id: 1,
    postId: 1,
    author: 'Mehmet Yılmaz',
    timestamp: '2024-08-10T10:30:00Z',
    content: 'Harika bir özet! ChatGPT-4o\'nun multimodal yetenekleri gerçekten de oyun değiştirici. Teşekkürler Elif Hanım.',
    avatarUrl: 'https://picsum.photos/seed/mehmet/128/128'
  },
  {
    id: 2,
    postId: 1,
    author: 'Ayşe Güler',
    timestamp: '2024-08-10T11:00:00Z',
    content: 'Microsoft Copilot\'un Office entegrasyonu günlük işlerimi çok kolaylaştırdı. Kesinlikle tavsiye ederim.',
    avatarUrl: 'https://picsum.photos/seed/ayse/128/128'
  },
  {
    id: 3,
    postId: 1,
    author: 'Elif Kara',
    timestamp: '2024-08-10T11:15:00Z',
    content: 'Kesinlikle Ayşe Hanım, Copilot özellikle kurumsal dünyada büyük bir verimlilik artışı sağlıyor.',
    avatarUrl: 'https://picsum.photos/seed/elif/128/128',
    parentId: 2
  },
  // Comments for Post 2
  {
    id: 4,
    postId: 2,
    author: 'Fatma Öztürk',
    timestamp: '2024-08-08T14:00:00Z',
    content: 'Bu yazı tam zamanında geldi. Dijital detoks yapmayı düşünüyordum, bu adımlar harika bir başlangıç olacak.',
    avatarUrl: 'https://picsum.photos/seed/fatma/128/128'
  },
  {
    id: 5,
    postId: 2,
    author: 'Barış Cengiz',
    timestamp: '2024-08-08T15:30:00Z',
    content: 'Beğenmenize sevindim Fatma Hanım! Küçük adımlarla başlamak en iyisi.',
    avatarUrl: 'https://picsum.photos/seed/baris/128/128',
    parentId: 4
  },
  {
    id: 6,
    postId: 2,
    author: 'Can Tekin',
    timestamp: '2024-08-09T09:00:00Z',
    content: 'Uygulama temizliği yaptım ve telefonumun ne kadar sadeleştiğine inanamıyorum. Zihinsel olarak da bir ferahlık hissettim.',
    avatarUrl: 'https://picsum.photos/seed/can/128/128'
  }
];