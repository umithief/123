import { Component, ChangeDetectionStrategy, output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-confetti',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './confetti.component.html',
  styleUrls: ['./confetti.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConfettiComponent implements OnInit {
  animationEnd = output<void>();
  confettiPieces = new Array(150);

  ngOnInit(): void {
    setTimeout(() => {
      this.animationEnd.emit();
    }, 4500); // Should be slightly less than animation duration
  }

  // Helper to generate random values for CSS variables
  rand(min: number, max: number): number {
    return Math.random() * (max - min) + min;
  }
}
