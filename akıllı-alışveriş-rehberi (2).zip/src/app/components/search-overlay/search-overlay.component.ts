import { Component, ChangeDetectionStrategy, output, inject, computed, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { BlogService } from '../../../services/blog.service';
import { Post } from '../../../models/post.model';
import { HighlightPipe } from '../../../pipes/highlight.pipe';
import { ImageOptimizerPipe } from '../../../app/pipes/image-optimizer.pipe';

@Component({
  selector: 'app-search-overlay',
  imports: [CommonModule, ReactiveFormsModule, HighlightPipe, NgOptimizedImage, ImageOptimizerPipe],
  templateUrl: './search-overlay.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SearchOverlayComponent implements AfterViewInit {
  private blogService = inject(BlogService);
  private router = inject(Router);
  
  close = output<void>();

  searchControl = new FormControl('');
  
  @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;

  searchResults = this.blogService.filteredPosts;
  searchTerm = this.blogService.searchTerm;

  constructor() {
    this.searchControl.valueChanges.pipe(
      debounceTime(200),
      distinctUntilChanged()
    ).subscribe(term => {
      this.blogService.search(term || '');
    });
  }
  
  ngAfterViewInit(): void {
    // Automatically focus the input when the component loads
    setTimeout(() => this.searchInput.nativeElement.focus(), 100);
  }

  onClose(): void {
    this.close.emit();
  }

  selectPost(post: Post): void {
    this.router.navigate(['/blog', post.id]);
    this.onClose();
  }
}
