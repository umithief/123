import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReadingStreakService } from '../../../services/reading-streak.service';

@Component({
  selector: 'app-reading-streak',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reading-streak.component.html',
  styleUrls: ['./reading-streak.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReadingStreakComponent {
  private readingStreakService = inject(ReadingStreakService);

  streakCount = this.readingStreakService.streakCount;
  isStreakActive = this.readingStreakService.isStreakActive;
}
