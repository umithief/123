import { Component, ChangeDetectionStrategy, inject, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Post, HtmlBlock } from '../../../models/post.model';
import { DOCUMENT } from '@angular/common';

declare var html2canvas: any;
declare var jspdf: any;

@Component({
  selector: 'app-pdf-magazine-export',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pdf-magazine-export.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PdfMagazineExportComponent {
  post = input.required<Post>();
  loading = signal(false);
  private document = inject(DOCUMENT);

  async downloadAsPdf() {
    if (this.loading()) return;
    this.loading.set(true);

    const postData = this.post();

    // --- Pre-fetch all images and convert to data URLs ---
    const tempDiv = this.document.createElement('div');
    tempDiv.innerHTML = postData.content
      .filter(block => block.type === 'html')
      .map(block => (block as HtmlBlock).content)
      .join('');
    
    const imageUrls = [
      postData.imageUrl,
      // FIX: Explicitly type `img` as HTMLImageElement to resolve property 'src' does not exist error.
      ...Array.from(tempDiv.getElementsByTagName('img')).map((img: HTMLImageElement) => img.src)
    ];
    const uniqueImageUrls = [...new Set(imageUrls)];
    const urlToDataUrlMap = new Map<string, string>();

    const imageFetchPromises = uniqueImageUrls.map(async (url) => {
      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Failed to fetch image: ${url} (status: ${response.status})`);
        const blob = await response.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });
        urlToDataUrlMap.set(url, dataUrl);
      } catch (error) {
        console.error(`Could not convert image to data URL: ${url}`, error);
      }
    });

    await Promise.all(imageFetchPromises);
    // --- End of new logic ---

    const magazineContainer = this.document.createElement('div');
    magazineContainer.style.position = 'fixed';
    magazineContainer.style.left = '-9999px';
    magazineContainer.style.top = '0px';

    magazineContainer.innerHTML = this.createMagazineHtml(postData, urlToDataUrlMap);
    this.document.body.appendChild(magazineContainer);

    try {
      // Use requestAnimationFrame and a short timeout to ensure the browser has fully rendered the off-screen element.
      await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 200)));

      const contentToCapture = magazineContainer.firstChild as HTMLElement;
      if (!contentToCapture) {
        throw new Error('PDF container not found');
      }

      const canvas = await html2canvas(contentToCapture, {
        scale: 2,
        useCORS: true, 
        logging: false,
        width: contentToCapture.scrollWidth,
        height: contentToCapture.scrollHeight,
        windowWidth: contentToCapture.scrollWidth,
        windowHeight: contentToCapture.scrollHeight
      });
      
      const imgData = canvas.toDataURL('image/jpeg', 0.9);
      const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;
      
      const ratio = canvasWidth / pdfWidth;
      const canvasHeightInPdf = canvasHeight / ratio;
      
      let position = 0;
      let page = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, canvasHeightInPdf);
      let heightLeft = canvasHeightInPdf - pdfHeight;

      while (heightLeft > 0) {
        page++;
        position = -(pdfHeight * page);
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, canvasHeightInPdf);
        heightLeft -= pdfHeight;
      }
      
      const fileName = `${postData.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.pdf`;
      pdf.save(fileName);

    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      this.document.body.removeChild(magazineContainer);
      this.loading.set(false);
    }
  }

  private createMagazineHtml(post: Post, urlMap: Map<string, string>): string {
    const contentHtml = post.content
        .filter(block => block.type === 'html')
        .map(block => (block as HtmlBlock).content)
        .join('');

    // Remove scripts/styles
    let sanitizedContent = contentHtml
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '');

    // Replace image src attributes with data URLs
    const tempDiv = this.document.createElement('div');
    tempDiv.innerHTML = sanitizedContent;
    const images = Array.from(tempDiv.getElementsByTagName('img'));
    // FIX: Explicitly type `img` as HTMLImageElement to resolve property 'src' does not exist error.
    images.forEach((img: HTMLImageElement) => {
      // Use the mapped data URL if available, otherwise keep original src
      if (urlMap.has(img.src)) {
        img.src = urlMap.get(img.src)!;
      }
    });
    sanitizedContent = tempDiv.innerHTML;

    // Use mapped data URL for cover image
    const coverImageUrl = urlMap.get(post.imageUrl) || post.imageUrl;

    return `
      <div style="width: 210mm; background: white; color: black; font-family: 'Times New Roman', Times, serif;">
        <div style="width: 210mm; height: 297mm; position: relative; display: flex; align-items: center; justify-content: center; color: white; text-align: center; padding: 40px; box-sizing: border-box; overflow: hidden;">
          <img src="${coverImageUrl}" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: 1;">
          <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.4); z-index: 2;"></div>
          <h1 style="font-size: 60px; line-height: 1.2; font-weight: bold; text-shadow: 2px 2px 8px rgba(0,0,0,0.7); z-index: 3;">${post.title}</h1>
        </div>
        <div style="padding: 20mm; font-size: 11pt; line-height: 1.6; orphans: 3; widows: 3;">
           <div style="margin-bottom: 1em;">
              <h2 style="font-size: 24pt; line-height: 1.2; font-weight: bold; margin-bottom: 0.5em;">${post.title}</h2>
              <p style="font-style: italic; color: #555;">${post.author} - ${post.publicationDate}</p>
           </div>
           ${sanitizedContent}
        </div>
      </div>
    `;
  }
}
