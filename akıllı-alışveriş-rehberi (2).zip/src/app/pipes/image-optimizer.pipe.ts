import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'imageOptimizer',
  standalone: true,
})
export class ImageOptimizerPipe implements PipeTransform {
  transform(value: string | undefined | null): string {
    if (!value) {
      return '';
    }

    try {
      const url = new URL(value);
      const hostname = url.hostname.toLowerCase();

      // Handle Unsplash and Firebase Storage
      const cdnDomains = ['images.unsplash.com', 'firebasestorage.googleapis.com'];
      if (cdnDomains.includes(hostname)) {
        url.searchParams.set('w', '800');
        url.searchParams.set('q', '80');
        url.searchParams.set('format', 'webp');
        return url.toString();
      }

      // Handle Picsum Photos to request WebP format
      if (hostname === 'picsum.photos') {
        // Check if the path already has a file extension (e.g., .jpg, .webp)
        const hasExtension = /\.\w{3,4}$/.test(url.pathname);
        if (!hasExtension && url.pathname.length > 1) { // length > 1 to avoid changing "https://picsum.photos/"
           url.pathname += '.webp';
           return url.toString();
        }
      }
    } catch (e) {
      // If value is not a valid URL, it will throw. Return original value.
      return value;
    }

    // If not a supported domain, return original URL
    return value;
  }
}
