import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { adminGuard } from './guards/admin.guard';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { AdminPostsComponent } from './admin/admin-posts/admin-posts.component';
import { AdminCommentsComponent } from './admin/admin-comments/admin-comments.component';
import { AdminUsersComponent } from './admin/admin-users/admin-users.component';

export const routes: Routes = [
  { path: '', component: HomeComponent, title: 'Akıllı Alışveriş Rehberi' },
  { 
    path: 'blog/:id', 
    loadComponent: () => import('./components/post-detail/post-detail.component').then(c => c.PostDetailComponent), 
    title: 'Rehber Detayı' 
  },
  { 
    path: 'author/:name', 
    loadComponent: () => import('./components/author-profile/author-profile.component').then(c => c.AuthorProfileComponent), 
    title: 'Yazar Profili' 
  },
  { 
    path: 'profile', 
    loadComponent: () => import('./components/user-profile/user-profile.component').then(c => c.UserProfileComponent), 
    title: 'Kullanıcı Profili' 
  },
  { 
    path: 'admin', 
    loadComponent: () => import('./admin/admin-layout/admin-layout.component').then(c => c.AdminLayoutComponent),
    canActivate: [adminGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: AdminDashboardComponent, title: 'Admin Paneli - Genel Bakış' },
      { path: 'posts', component: AdminPostsComponent, title: 'Admin Paneli - Yazılar' },
      { path: 'comments', component: AdminCommentsComponent, title: 'Admin Paneli - Yorumlar' },
      { path: 'users', component: AdminUsersComponent, title: 'Admin Paneli - Kullanıcılar' }
    ]
  },
  { 
    path: '**', 
    loadComponent: () => import('./components/not-found/not-found.component').then(c => c.NotFoundComponent), 
    title: '404 - Sayfa Bulunamadı' 
  }
];